const router = require('express').Router();
const c = require('../controllers/userController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect, authorize('admin'));
router.get('/', c.list);
router.put('/:id/active', c.setActive);
router.delete('/:id', c.remove);

module.exports = router;
