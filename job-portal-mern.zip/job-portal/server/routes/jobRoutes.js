const router = require('express').Router();
const c = require('../controllers/jobController');
const { protect, authorize } = require('../middleware/auth');

router.get('/', c.list);
router.get('/mine', protect, authorize('employer', 'admin'), c.mine);
router.post('/', protect, authorize('employer', 'admin'), c.create);
router.get('/:id', c.getOne);
router.put('/:id', protect, authorize('employer', 'admin'), c.update);
router.delete('/:id', protect, authorize('employer', 'admin'), c.remove);

module.exports = router;
