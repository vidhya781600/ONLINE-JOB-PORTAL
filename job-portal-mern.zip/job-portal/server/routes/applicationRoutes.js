const router = require('express').Router();
const c = require('../controllers/applicationController');
const { protect, authorize } = require('../middleware/auth');

router.post('/', protect, authorize('applicant'), c.apply);
router.get('/mine', protect, authorize('applicant'), c.mine);
router.get('/', protect, authorize('employer', 'admin'), c.list);
router.get('/job/:jobId', protect, authorize('employer', 'admin'), c.forJob);
router.put('/:id/status', protect, authorize('employer', 'admin'), c.updateStatus);
router.put('/:id/withdraw', protect, authorize('applicant'), c.withdraw);
router.delete('/:id', protect, authorize('applicant', 'admin'), c.remove);

module.exports = router;
