const router = require('express').Router();
const c = require('../controllers/applicantController');
const { protect, authorize } = require('../middleware/auth');

router.get('/me', protect, authorize('applicant'), c.getMe);
router.put('/me', protect, authorize('applicant'), c.updateMe);
router.get('/', protect, authorize('admin'), c.list);
router.get('/:id', protect, authorize('admin', 'employer'), c.getOne);

module.exports = router;
