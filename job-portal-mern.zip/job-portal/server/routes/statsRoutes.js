const router = require('express').Router();
const c = require('../controllers/statsController');
const { protect } = require('../middleware/auth');

router.get('/public', c.publicStats);
router.get('/', protect, c.dashboard);

module.exports = router;
