const Company = require('../models/Company');
const Job = require('../models/Job');
const asyncHandler = require('../utils/asyncHandler');
const httpError = require('../utils/httpError');
const { escapeRegex, pick, numOrNull, getPaging, canManage } = require('../utils/helpers');
const { deleteCompanies } = require('../utils/cascade');

const FIELDS = ['name', 'industry', 'location', 'website', 'size', 'description'];

const buildData = (body) => {
  const data = pick(body, FIELDS);
  if (body.foundedYear !== undefined) data.foundedYear = numOrNull(body.foundedYear) || undefined;
  return data;
};

const withOpenJobCounts = async (companies) => {
  const ids = companies.map((c) => c._id);
  const rows = await Job.aggregate([
    { $match: { company: { $in: ids }, status: 'open' } },
    { $group: { _id: '$company', count: { $sum: 1 } } },
  ]);
  const counts = new Map(rows.map((r) => [String(r._id), r.count]));
  return companies.map((c) => ({ ...c, openJobs: counts.get(String(c._id)) || 0 }));
};

// GET /api/companies  (public)
exports.list = asyncHandler(async (req, res) => {
  const { search } = req.query;
  const filter = {};
  if (search) {
    const rx = new RegExp(escapeRegex(search), 'i');
    filter.$or = [{ name: rx }, { industry: rx }, { location: rx }];
  }
  const { page, limit, skip } = getPaging(req.query, 12);
  const [total, found] = await Promise.all([
    Company.countDocuments(filter),
    Company.find(filter).sort({ name: 1 }).skip(skip).limit(limit).lean(),
  ]);
  const companies = await withOpenJobCounts(found);
  res.json({ companies, total, page, pages: Math.ceil(total / limit) || 1 });
});

// GET /api/companies/mine  (employer: own companies, admin: all)
exports.mine = asyncHandler(async (req, res) => {
  const filter = req.user.role === 'admin' ? {} : { owner: req.user._id };
  const found = await Company.find(filter).sort({ createdAt: -1 }).lean();
  res.json(await withOpenJobCounts(found));
});

// GET /api/companies/:id  (public)
exports.getOne = asyncHandler(async (req, res) => {
  const company = await Company.findById(req.params.id).lean();
  if (!company) throw httpError(404, 'Company not found.');
  const jobs = await Job.find({ company: company._id, status: 'open' })
    .sort({ createdAt: -1 })
    .populate('company', 'name location industry')
    .lean();
  res.json({ ...company, jobs });
});

// POST /api/companies  (employer, admin)
exports.create = asyncHandler(async (req, res) => {
  const company = await Company.create({ ...buildData(req.body), owner: req.user._id });
  res.status(201).json(company);
});

// PUT /api/companies/:id  (owner, admin)
exports.update = asyncHandler(async (req, res) => {
  const company = await Company.findById(req.params.id);
  if (!company) throw httpError(404, 'Company not found.');
  if (!canManage(req.user, company.owner)) throw httpError(403, 'You can only edit your own companies.');
  company.set(buildData(req.body));
  await company.save();
  res.json(company);
});

// DELETE /api/companies/:id  (owner, admin) - also removes its jobs and applications
exports.remove = asyncHandler(async (req, res) => {
  const company = await Company.findById(req.params.id);
  if (!company) throw httpError(404, 'Company not found.');
  if (!canManage(req.user, company.owner)) throw httpError(403, 'You can only delete your own companies.');
  await deleteCompanies([company._id]);
  res.json({ message: 'Company and its jobs were deleted.' });
});
