const Job = require('../models/Job');
const Company = require('../models/Company');
const Application = require('../models/Application');
const asyncHandler = require('../utils/asyncHandler');
const httpError = require('../utils/httpError');
const { escapeRegex, pick, toList, numOrNull, getPaging, isId, canManage } = require('../utils/helpers');
const { deleteJobs } = require('../utils/cascade');

const buildData = (body) => {
  const data = pick(body, [
    'title',
    'description',
    'location',
    'jobType',
    'category',
    'experienceLevel',
    'currency',
    'status',
  ]);
  if (body.requirements !== undefined) data.requirements = toList(body.requirements);
  if (body.skills !== undefined) data.skills = toList(body.skills);
  if (body.salaryMin !== undefined) data.salaryMin = numOrNull(body.salaryMin);
  if (body.salaryMax !== undefined) data.salaryMax = numOrNull(body.salaryMax);
  if (body.openings !== undefined) {
    const n = numOrNull(body.openings);
    data.openings = n === null ? 1 : n;
  }
  if (body.deadline !== undefined) data.deadline = body.deadline ? new Date(body.deadline) : null;
  return data;
};

// GET /api/jobs  (public: open jobs, filters + pagination)
exports.list = asyncHandler(async (req, res) => {
  const { search, location, jobType, category, experienceLevel, company } = req.query;
  const and = [{ status: 'open' }, { $or: [{ deadline: null }, { deadline: { $gte: new Date() } }] }];

  if (search) {
    const rx = new RegExp(escapeRegex(search), 'i');
    and.push({ $or: [{ title: rx }, { skills: rx }, { category: rx }, { description: rx }] });
  }
  if (location) and.push({ location: new RegExp(escapeRegex(location), 'i') });
  if (jobType) and.push({ jobType });
  if (category) and.push({ category });
  if (experienceLevel) and.push({ experienceLevel });
  if (company && isId(company)) and.push({ company });

  const filter = { $and: and };
  const { page, limit, skip } = getPaging(req.query, 10);
  const [total, jobs] = await Promise.all([
    Job.countDocuments(filter),
    Job.find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('company', 'name location industry')
      .lean(),
  ]);
  res.json({ jobs, total, page, pages: Math.ceil(total / limit) || 1 });
});

// GET /api/jobs/mine  (employer: own jobs, admin: all jobs) with applicant counts
exports.mine = asyncHandler(async (req, res) => {
  const filter = req.user.role === 'admin' ? {} : { postedBy: req.user._id };
  const jobs = await Job.find(filter).sort({ createdAt: -1 }).populate('company', 'name').lean();

  const rows = await Application.aggregate([
    { $match: { job: { $in: jobs.map((j) => j._id) } } },
    { $group: { _id: '$job', count: { $sum: 1 } } },
  ]);
  const counts = new Map(rows.map((r) => [String(r._id), r.count]));
  res.json(jobs.map((j) => ({ ...j, applicationCount: counts.get(String(j._id)) || 0 })));
});

// GET /api/jobs/:id  (public)
exports.getOne = asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id).populate('company').lean();
  if (!job) throw httpError(404, 'Job not found.');
  res.json(job);
});

// POST /api/jobs  (employer, admin)
exports.create = asyncHandler(async (req, res) => {
  const { company: companyId } = req.body;
  if (!companyId || !isId(companyId)) throw httpError(400, 'Please choose a company for this job.');
  const company = await Company.findById(companyId);
  if (!company) throw httpError(404, 'Company not found.');
  if (!canManage(req.user, company.owner)) {
    throw httpError(403, 'You can only post jobs for your own companies.');
  }
  const job = await Job.create({ ...buildData(req.body), company: company._id, postedBy: req.user._id });
  res.status(201).json(job);
});

// PUT /api/jobs/:id  (owner, admin)
exports.update = asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id);
  if (!job) throw httpError(404, 'Job not found.');
  if (!canManage(req.user, job.postedBy)) throw httpError(403, 'You can only edit your own jobs.');
  job.set(buildData(req.body));
  await job.save();
  res.json(job);
});

// DELETE /api/jobs/:id  (owner, admin) - also removes its applications
exports.remove = asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id);
  if (!job) throw httpError(404, 'Job not found.');
  if (!canManage(req.user, job.postedBy)) throw httpError(403, 'You can only delete your own jobs.');
  await deleteJobs([job._id]);
  res.json({ message: 'Job and its applications were deleted.' });
});
