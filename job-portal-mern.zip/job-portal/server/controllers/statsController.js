const User = require('../models/User');
const Company = require('../models/Company');
const Job = require('../models/Job');
const Applicant = require('../models/Applicant');
const Application = require('../models/Application');
const asyncHandler = require('../utils/asyncHandler');
const { APPLICATION_STATUSES } = require('../constants');

const byStatus = async (match) => {
  const rows = await Application.aggregate([
    { $match: match },
    { $group: { _id: '$status', count: { $sum: 1 } } },
  ]);
  const out = {};
  APPLICATION_STATUSES.forEach((s) => {
    out[s] = 0;
  });
  rows.forEach((r) => {
    out[r._id] = r.count;
  });
  return out;
};

// GET /api/stats/public
exports.publicStats = asyncHandler(async (req, res) => {
  const [openJobs, companies] = await Promise.all([
    Job.countDocuments({ status: 'open' }),
    Company.countDocuments(),
  ]);
  res.json({ openJobs, companies });
});

// GET /api/stats  (role aware)
exports.dashboard = asyncHandler(async (req, res) => {
  const { role, _id } = req.user;

  if (role === 'admin') {
    const [users, employers, applicants, companies, jobs, openJobs, applications, statuses] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ role: 'employer' }),
      User.countDocuments({ role: 'applicant' }),
      Company.countDocuments(),
      Job.countDocuments(),
      Job.countDocuments({ status: 'open' }),
      Application.countDocuments(),
      byStatus({}),
    ]);
    return res.json({
      role,
      totals: { users, employers, applicants, companies, jobs, openJobs, applications },
      byStatus: statuses,
    });
  }

  if (role === 'employer') {
    const companyIds = await Company.distinct('_id', { owner: _id });
    const [jobs, openJobs, applications, statuses] = await Promise.all([
      Job.countDocuments({ postedBy: _id }),
      Job.countDocuments({ postedBy: _id, status: 'open' }),
      Application.countDocuments({ company: { $in: companyIds } }),
      byStatus({ company: { $in: companyIds } }),
    ]);
    return res.json({
      role,
      totals: { companies: companyIds.length, jobs, openJobs, applications },
      byStatus: statuses,
    });
  }

  const profile = await Applicant.findOne({ user: _id });
  const match = profile ? { applicant: profile._id } : { applicant: null };
  const [applications, statuses] = await Promise.all([Application.countDocuments(match), byStatus(match)]);
  res.json({ role, totals: { applications }, byStatus: statuses });
});
