const Application = require('../models/Application');
const Applicant = require('../models/Applicant');
const Job = require('../models/Job');
const Company = require('../models/Company');
const asyncHandler = require('../utils/asyncHandler');
const httpError = require('../utils/httpError');
const { canManage } = require('../utils/helpers');
const { APPLICATION_STATUSES } = require('../constants');

const applicantPopulate = { path: 'applicant', populate: { path: 'user', select: 'name email' } };

// POST /api/applications  (applicant)
exports.apply = asyncHandler(async (req, res) => {
  const { jobId, coverLetter, resumeUrl } = req.body;
  if (!jobId) throw httpError(400, 'jobId is required.');

  const job = await Job.findById(jobId);
  if (!job) throw httpError(404, 'Job not found.');
  if (job.status !== 'open' || (job.deadline && job.deadline < new Date())) {
    throw httpError(400, 'This job is no longer accepting applications.');
  }

  let profile = await Applicant.findOne({ user: req.user._id });
  if (!profile) profile = await Applicant.create({ user: req.user._id });

  const existing = await Application.exists({ job: job._id, applicant: profile._id });
  if (existing) throw httpError(409, 'You have already applied to this job.');

  const application = await Application.create({
    job: job._id,
    company: job.company,
    applicant: profile._id,
    coverLetter: coverLetter || '',
    resumeUrl: resumeUrl || profile.resumeUrl || '',
    status: 'Applied',
    statusHistory: [{ status: 'Applied', changedBy: req.user._id }],
  });
  res.status(201).json(application);
});

// GET /api/applications/mine  (applicant)
exports.mine = asyncHandler(async (req, res) => {
  const profile = await Applicant.findOne({ user: req.user._id });
  if (!profile) return res.json([]);
  const applications = await Application.find({ applicant: profile._id })
    .sort({ createdAt: -1 })
    .populate('job', 'title location jobType status')
    .populate('company', 'name')
    .lean();
  res.json(applications);
});

// GET /api/applications  (employer: for own companies, admin: all)
exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.user.role === 'employer') {
    const companyIds = await Company.distinct('_id', { owner: req.user._id });
    filter.company = { $in: companyIds };
  }
  if (req.query.status && APPLICATION_STATUSES.includes(req.query.status)) {
    filter.status = req.query.status;
  }
  const applications = await Application.find(filter)
    .sort({ createdAt: -1 })
    .limit(500)
    .populate('job', 'title location jobType')
    .populate('company', 'name')
    .populate(applicantPopulate)
    .lean();
  res.json(applications);
});

// GET /api/applications/job/:jobId  (job owner, admin)
exports.forJob = asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.jobId).populate('company', 'name').lean();
  if (!job) throw httpError(404, 'Job not found.');
  if (!canManage(req.user, job.postedBy)) {
    throw httpError(403, 'You can only view applications for your own jobs.');
  }
  const applications = await Application.find({ job: job._id })
    .sort({ createdAt: -1 })
    .populate(applicantPopulate)
    .lean();
  res.json({ job, applications });
});

// PUT /api/applications/:id/status  (job owner, admin)
exports.updateStatus = asyncHandler(async (req, res) => {
  const { status, note } = req.body;
  if (!APPLICATION_STATUSES.includes(status) || status === 'Withdrawn') {
    throw httpError(400, 'Please choose a valid status.');
  }
  const application = await Application.findById(req.params.id);
  if (!application) throw httpError(404, 'Application not found.');

  const job = await Job.findById(application.job);
  if (!job || !canManage(req.user, job.postedBy)) {
    throw httpError(403, 'You can only update applications for your own jobs.');
  }
  if (application.status === 'Withdrawn') {
    throw httpError(400, 'The applicant has withdrawn this application.');
  }

  if (application.status !== status) {
    application.status = status;
    application.statusHistory.push({ status, note: note || '', changedBy: req.user._id });
    await application.save();
  }
  await application.populate(applicantPopulate);
  res.json(application);
});

// PUT /api/applications/:id/withdraw  (applicant who owns it)
exports.withdraw = asyncHandler(async (req, res) => {
  const profile = await Applicant.findOne({ user: req.user._id });
  const application = await Application.findById(req.params.id);
  if (!application) throw httpError(404, 'Application not found.');
  if (!profile || String(application.applicant) !== String(profile._id)) {
    throw httpError(403, 'You can only withdraw your own applications.');
  }
  if (['Hired', 'Rejected', 'Withdrawn'].includes(application.status)) {
    throw httpError(400, `A ${application.status.toLowerCase()} application cannot be withdrawn.`);
  }
  application.status = 'Withdrawn';
  application.statusHistory.push({ status: 'Withdrawn', changedBy: req.user._id });
  await application.save();
  res.json(application);
});

// DELETE /api/applications/:id  (applicant who owns it, admin)
exports.remove = asyncHandler(async (req, res) => {
  const application = await Application.findById(req.params.id);
  if (!application) throw httpError(404, 'Application not found.');

  if (req.user.role !== 'admin') {
    const profile = await Applicant.findOne({ user: req.user._id });
    if (!profile || String(application.applicant) !== String(profile._id)) {
      throw httpError(403, 'You can only delete your own applications.');
    }
  }
  await Application.deleteOne({ _id: application._id });
  res.json({ message: 'Application deleted.' });
});
