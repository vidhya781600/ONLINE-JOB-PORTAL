const User = require('../models/User');
const Applicant = require('../models/Applicant');
const asyncHandler = require('../utils/asyncHandler');
const httpError = require('../utils/httpError');

const sendAuth = (res, status, user) => {
  res.status(status).json({ token: user.signToken(), user: user.toJSON() });
};

// POST /api/auth/register
exports.register = asyncHandler(async (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password) {
    throw httpError(400, 'Name, email and password are required.');
  }
  if (role && !['applicant', 'employer'].includes(role)) {
    throw httpError(400, 'Role must be either applicant or employer.');
  }

  const user = await User.create({ name, email, password, role: role || 'applicant' });

  if (user.role === 'applicant') {
    try {
      await Applicant.create({ user: user._id });
    } catch (err) {
      await User.deleteOne({ _id: user._id });
      throw err;
    }
  }
  sendAuth(res, 201, user);
});

// POST /api/auth/login
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) throw httpError(400, 'Email and password are required.');

  const user = await User.findOne({ email: String(email).toLowerCase().trim() }).select('+password');
  if (!user || !(await user.matchPassword(password))) {
    throw httpError(401, 'Invalid email or password.');
  }
  if (!user.isActive) throw httpError(403, 'This account has been deactivated.');

  sendAuth(res, 200, user);
});

// GET /api/auth/me
exports.me = asyncHandler(async (req, res) => {
  res.json(req.user);
});
