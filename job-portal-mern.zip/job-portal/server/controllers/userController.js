const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const httpError = require('../utils/httpError');
const { escapeRegex, getPaging } = require('../utils/helpers');
const { deleteUser } = require('../utils/cascade');
const { ROLES } = require('../constants');

// GET /api/users  (admin)
exports.list = asyncHandler(async (req, res) => {
  const { search, role } = req.query;
  const filter = {};
  if (role && ROLES.includes(role)) filter.role = role;
  if (search) {
    const rx = new RegExp(escapeRegex(search), 'i');
    filter.$or = [{ name: rx }, { email: rx }];
  }
  const { page, limit, skip } = getPaging(req.query, 50);
  const [total, users] = await Promise.all([
    User.countDocuments(filter),
    User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
  ]);
  res.json({ users, total, page, pages: Math.ceil(total / limit) || 1 });
});

// PUT /api/users/:id/active  (admin)
exports.setActive = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw httpError(404, 'User not found.');
  if (String(user._id) === String(req.user._id)) throw httpError(400, 'You cannot deactivate your own account.');
  if (user.role === 'admin') throw httpError(400, 'Admin accounts cannot be deactivated here.');
  user.isActive = Boolean(req.body.isActive);
  await user.save();
  res.json(user);
});

// DELETE /api/users/:id  (admin) - cascades to the user's data
exports.remove = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw httpError(404, 'User not found.');
  if (String(user._id) === String(req.user._id)) throw httpError(400, 'You cannot delete your own account.');
  if (user.role === 'admin') throw httpError(400, 'Admin accounts cannot be deleted here.');
  await deleteUser(user);
  res.json({ message: 'User and related data were deleted.' });
});
