const Applicant = require('../models/Applicant');
const Application = require('../models/Application');
const Company = require('../models/Company');
const asyncHandler = require('../utils/asyncHandler');
const httpError = require('../utils/httpError');
const { pick, toList, numOrNull, getPaging } = require('../utils/helpers');

const getOrCreateProfile = async (user) => {
  let profile = await Applicant.findOne({ user: user._id });
  if (!profile) profile = await Applicant.create({ user: user._id });
  return profile;
};

// GET /api/applicants/me  (applicant)
exports.getMe = asyncHandler(async (req, res) => {
  const profile = await getOrCreateProfile(req.user);
  await profile.populate('user', 'name email');
  res.json(profile);
});

// PUT /api/applicants/me  (applicant)
exports.updateMe = asyncHandler(async (req, res) => {
  const profile = await getOrCreateProfile(req.user);
  const data = pick(req.body, ['headline', 'phone', 'location', 'summary', 'education', 'resumeUrl', 'linkedin']);
  if (req.body.skills !== undefined) data.skills = toList(req.body.skills);
  if (req.body.experienceYears !== undefined) data.experienceYears = numOrNull(req.body.experienceYears) || 0;
  profile.set(data);
  await profile.save();

  if (req.body.name !== undefined) {
    const name = String(req.body.name).trim();
    if (!name) throw httpError(400, 'Name cannot be empty.');
    req.user.name = name;
    await req.user.save();
  }
  await profile.populate('user', 'name email');
  res.json(profile);
});

// GET /api/applicants  (admin)
exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip } = getPaging(req.query, 20);
  const [total, applicants] = await Promise.all([
    Applicant.countDocuments(),
    Applicant.find().sort({ createdAt: -1 }).skip(skip).limit(limit).populate('user', 'name email isActive').lean(),
  ]);
  res.json({ applicants, total, page, pages: Math.ceil(total / limit) || 1 });
});

// GET /api/applicants/:id  (admin, or an employer who received an application from them)
exports.getOne = asyncHandler(async (req, res) => {
  const profile = await Applicant.findById(req.params.id).populate('user', 'name email').lean();
  if (!profile) throw httpError(404, 'Applicant not found.');

  if (req.user.role === 'employer') {
    const companyIds = await Company.distinct('_id', { owner: req.user._id });
    const hasApplied = await Application.exists({ applicant: profile._id, company: { $in: companyIds } });
    if (!hasApplied) throw httpError(403, 'You can only view applicants who applied to your jobs.');
  }
  res.json(profile);
});
