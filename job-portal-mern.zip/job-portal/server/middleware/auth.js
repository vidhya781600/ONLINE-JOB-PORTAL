const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const httpError = require('../utils/httpError');

// Verifies the Bearer token and attaches the user to req.user.
const protect = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) throw httpError(401, 'Not authenticated. Please log in.');

  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch (e) {
    throw httpError(401, 'Your session has expired or is invalid. Please log in again.');
  }

  const user = await User.findById(decoded.id);
  if (!user) throw httpError(401, 'This account no longer exists.');
  if (!user.isActive) throw httpError(403, 'This account has been deactivated.');

  req.user = user;
  next();
});

// Role-based access control. Use after protect.
const authorize = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return next(httpError(403, 'You do not have permission to do this.'));
  }
  next();
};

module.exports = { protect, authorize };
