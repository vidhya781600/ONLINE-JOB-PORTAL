/*
 * MongoDB setup script.
 *
 *   npm run seed           clears the database and loads demo data
 *   npm run seed:destroy   clears the database only
 *
 * Demo logins (printed again at the end of the run):
 *   admin      admin@jobportal.com      Admin@123
 *   employers  employer1@jobportal.com  Employer@123   (also employer2, employer3)
 *   applicants applicant1@jobportal.com Applicant@123  (also applicant2 to applicant5)
 */
require('./config/env');
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');
const Company = require('./models/Company');
const Job = require('./models/Job');
const Applicant = require('./models/Applicant');
const Application = require('./models/Application');

const destroyOnly = process.argv.includes('--destroy');

const daysFromNow = (n) => new Date(Date.now() + n * 24 * 60 * 60 * 1000);

const clearAll = async () => {
  await Application.deleteMany({});
  await Job.deleteMany({});
  await Applicant.deleteMany({});
  await Company.deleteMany({});
  await User.deleteMany({});
};

const run = async () => {
  await connectDB();
  await clearAll();
  console.log('Existing data cleared.');

  if (destroyOnly) {
    console.log('Database emptied. Nothing was seeded (--destroy).');
    return;
  }

  // Make sure unique indexes exist before inserting.
  await Promise.all([User, Company, Job, Applicant, Application].map((m) => m.init()));

  // ---- Users ---------------------------------------------------------------
  const admin = await User.create({
    name: 'Portal Admin',
    email: 'admin@jobportal.com',
    password: 'Admin@123',
    role: 'admin',
  });

  const employerNames = ['Meera Iyer', 'Daniel Brooks', 'Sofia Alvarez'];
  const employers = [];
  for (let i = 0; i < employerNames.length; i += 1) {
    employers.push(
      await User.create({
        name: employerNames[i],
        email: `employer${i + 1}@jobportal.com`,
        password: 'Employer@123',
        role: 'employer',
      })
    );
  }

  const applicantData = [
    {
      name: 'Aarav Sharma',
      headline: 'Full-stack developer with a focus on React',
      phone: '+91 98765 43210',
      location: 'Hyderabad, India',
      skills: ['React', 'Node.js', 'MongoDB', 'Express', 'JavaScript'],
      experienceYears: 2,
      education: 'B.Tech, Computer Science',
      summary: 'Built and shipped several MERN projects, comfortable owning features from schema to UI.',
      resumeUrl: 'https://example.com/resumes/aarav-sharma.pdf',
      linkedin: 'https://linkedin.com/in/aarav-sharma-demo',
    },
    {
      name: 'Emily Carter',
      headline: 'Product designer who prototypes in code',
      phone: '+1 415 555 0136',
      location: 'San Francisco, USA',
      skills: ['Figma', 'UX Research', 'Prototyping', 'CSS'],
      experienceYears: 4,
      education: 'BFA, Interaction Design',
      summary: 'Four years designing onboarding and dashboard flows for B2B software.',
      resumeUrl: 'https://example.com/resumes/emily-carter.pdf',
      linkedin: 'https://linkedin.com/in/emily-carter-demo',
    },
    {
      name: "Liam O'Connor",
      headline: 'Data analyst, SQL and dashboards',
      phone: '+44 20 7946 0321',
      location: 'London, UK',
      skills: ['SQL', 'Python', 'Tableau', 'Excel'],
      experienceYears: 3,
      education: 'BSc, Statistics',
      summary: 'Turns messy operational data into weekly dashboards that teams actually read.',
      resumeUrl: 'https://example.com/resumes/liam-oconnor.pdf',
      linkedin: '',
    },
    {
      name: 'Fatima Khan',
      headline: 'Marketing coordinator, content and email',
      phone: '+971 50 123 4567',
      location: 'Dubai, UAE',
      skills: ['Content Writing', 'SEO', 'Email Marketing', 'Analytics'],
      experienceYears: 1,
      education: 'BBA, Marketing',
      summary: 'Runs newsletters and blog calendars; looking for a team that values measurable content.',
      resumeUrl: 'https://example.com/resumes/fatima-khan.pdf',
      linkedin: '',
    },
    {
      name: 'Noah Williams',
      headline: 'Recent graduate looking for a first engineering role',
      phone: '+1 212 555 0190',
      location: 'New York, USA',
      skills: ['Java', 'Spring Boot', 'SQL', 'Git'],
      experienceYears: 0,
      education: 'B.S., Computer Science',
      summary: 'Completed two internships and a capstone building a booking platform.',
      resumeUrl: 'https://example.com/resumes/noah-williams.pdf',
      linkedin: '',
    },
  ];

  const applicants = []; // { user, profile }
  for (let i = 0; i < applicantData.length; i += 1) {
    const { name, ...profileFields } = applicantData[i];
    const user = await User.create({
      name,
      email: `applicant${i + 1}@jobportal.com`,
      password: 'Applicant@123',
      role: 'applicant',
    });
    const profile = await Applicant.create({ user: user._id, ...profileFields });
    applicants.push({ user, profile });
  }

  // ---- Companies -----------------------------------------------------------
  const companyDocs = await Company.insertMany([
    {
      owner: employers[0]._id,
      name: 'Northwind Labs',
      industry: 'Software',
      location: 'Austin, USA',
      website: 'https://northwind.example.com',
      size: '51-200',
      foundedYear: 2014,
      description: 'Northwind Labs builds logistics software for mid-sized shippers. Small product teams, weekly releases.',
    },
    {
      owner: employers[0]._id,
      name: 'Pixel & Pine Studio',
      industry: 'Design',
      location: 'Berlin, Germany',
      website: 'https://pixelpine.example.com',
      size: '11-50',
      foundedYear: 2018,
      description: 'An independent studio designing apps and brand systems for climate and mobility startups.',
    },
    {
      owner: employers[1]._id,
      name: 'Brightpath Finance',
      industry: 'Financial Services',
      location: 'London, UK',
      website: 'https://brightpath.example.com',
      size: '201-500',
      foundedYear: 2009,
      description: 'Brightpath offers savings and lending products for small businesses, with teams across three offices.',
    },
    {
      owner: employers[2]._id,
      name: 'Greenleaf Health',
      industry: 'Healthcare',
      location: 'Bengaluru, India',
      website: 'https://greenleaf.example.com',
      size: '501+',
      foundedYear: 2005,
      description: 'Greenleaf runs outpatient clinics and a telehealth platform serving more than a million patients.',
    },
  ]);
  const [northwind, pixelPine, brightpath, greenleaf] = companyDocs;

  // ---- Jobs ----------------------------------------------------------------
  const jobSeed = [
    {
      company: northwind,
      title: 'Full-Stack Developer (MERN)',
      description:
        'Join the platform team building route-planning and tracking tools. You will own features end to end: MongoDB schemas, Express APIs and React interfaces.',
      requirements: ['2+ years with React and Node.js', 'Experience designing REST APIs', 'Comfortable with MongoDB indexing and aggregation'],
      skills: ['React', 'Node.js', 'MongoDB', 'Express'],
      location: 'Austin, USA',
      jobType: 'Full-time',
      category: 'Engineering',
      experienceLevel: 'Mid',
      salaryMin: 95000,
      salaryMax: 125000,
      openings: 2,
      deadline: daysFromNow(30),
    },
    {
      company: northwind,
      title: 'Junior Frontend Engineer',
      description: 'Help us turn design specs into fast, accessible React components for our customer dashboard.',
      requirements: ['Solid JavaScript and CSS fundamentals', 'Familiarity with React', 'Eagerness to learn from code review'],
      skills: ['React', 'JavaScript', 'CSS'],
      location: 'Remote',
      jobType: 'Remote',
      category: 'Engineering',
      experienceLevel: 'Entry',
      salaryMin: 60000,
      salaryMax: 75000,
      openings: 1,
      deadline: daysFromNow(21),
    },
    {
      company: northwind,
      title: 'Data Analyst, Operations',
      description: 'Analyze shipment and delivery data to find delays and cost savings, and present findings to operations leads.',
      requirements: ['Strong SQL', 'Experience with a BI tool', 'Clear written communication'],
      skills: ['SQL', 'Python', 'Tableau'],
      location: 'Austin, USA',
      jobType: 'Full-time',
      category: 'Data & Analytics',
      experienceLevel: 'Mid',
      salaryMin: 70000,
      salaryMax: 90000,
      openings: 1,
      deadline: daysFromNow(25),
    },
    {
      company: pixelPine,
      title: 'Product Designer',
      description: 'Design end-to-end flows for mobility and energy apps, from first sketch to developer handoff.',
      requirements: ['Portfolio showing shipped product work', 'Fluent in Figma', 'Comfortable running small user tests'],
      skills: ['Figma', 'UX Research', 'Prototyping'],
      location: 'Berlin, Germany',
      jobType: 'Full-time',
      category: 'Design',
      experienceLevel: 'Mid',
      salaryMin: 58000,
      salaryMax: 72000,
      currency: 'EUR',
      openings: 1,
      deadline: daysFromNow(28),
    },
    {
      company: pixelPine,
      title: 'Design Intern',
      description: 'A three-month paid internship working alongside senior designers on real client projects.',
      requirements: ['Currently studying or recently graduated in design', 'A small portfolio of personal or class projects'],
      skills: ['Figma', 'Illustration'],
      location: 'Berlin, Germany',
      jobType: 'Internship',
      category: 'Design',
      experienceLevel: 'Entry',
      salaryMin: 18000,
      salaryMax: 22000,
      currency: 'EUR',
      openings: 2,
      deadline: daysFromNow(14),
    },
    {
      company: pixelPine,
      title: 'Brand Strategist (Contract)',
      description: 'A six-month contract to lead naming and positioning workshops for two new client engagements.',
      requirements: ['5+ years in brand or marketing strategy', 'Experience facilitating workshops'],
      skills: ['Brand Strategy', 'Workshops', 'Copywriting'],
      location: 'Remote',
      jobType: 'Contract',
      category: 'Marketing',
      experienceLevel: 'Senior',
      salaryMin: 80000,
      salaryMax: 100000,
      currency: 'EUR',
      openings: 1,
      deadline: daysFromNow(18),
    },
    {
      company: brightpath,
      title: 'Financial Analyst',
      description: 'Build monthly forecasts, track loan portfolio performance and support leadership with scenario modelling.',
      requirements: ['Degree in finance, economics or similar', 'Advanced Excel', '2+ years in an analyst role'],
      skills: ['Excel', 'Financial Modelling', 'SQL'],
      location: 'London, UK',
      jobType: 'Full-time',
      category: 'Finance',
      experienceLevel: 'Mid',
      salaryMin: 48000,
      salaryMax: 62000,
      currency: 'GBP',
      openings: 1,
      deadline: daysFromNow(35),
    },
    {
      company: brightpath,
      title: 'Customer Support Specialist',
      description: 'Answer questions from small business customers by chat and phone and help us improve our help centre.',
      requirements: ['Excellent written English', 'Patience and a problem-solving mindset'],
      skills: ['Customer Service', 'Zendesk', 'Communication'],
      location: 'London, UK',
      jobType: 'Part-time',
      category: 'Customer Support',
      experienceLevel: 'Entry',
      salaryMin: 22000,
      salaryMax: 28000,
      currency: 'GBP',
      openings: 3,
      deadline: daysFromNow(20),
    },
    {
      company: brightpath,
      title: 'Senior Backend Engineer',
      description: 'Lead design of our payments ledger services. Hiring has closed for this role.',
      requirements: ['7+ years of backend experience', 'Experience with financial systems'],
      skills: ['Java', 'PostgreSQL', 'Kafka'],
      location: 'London, UK',
      jobType: 'Full-time',
      category: 'Engineering',
      experienceLevel: 'Senior',
      salaryMin: 90000,
      salaryMax: 120000,
      currency: 'GBP',
      openings: 1,
      status: 'closed',
      deadline: daysFromNow(-5),
    },
    {
      company: greenleaf,
      title: 'Digital Marketing Executive',
      description: 'Plan campaigns that help patients find the right clinic and book appointments online.',
      requirements: ['1+ year in digital marketing', 'Working knowledge of SEO and email tools'],
      skills: ['SEO', 'Email Marketing', 'Analytics', 'Content Writing'],
      location: 'Bengaluru, India',
      jobType: 'Full-time',
      category: 'Marketing',
      experienceLevel: 'Entry',
      salaryMin: 500000,
      salaryMax: 800000,
      currency: 'INR',
      openings: 2,
      deadline: daysFromNow(26),
    },
    {
      company: greenleaf,
      title: 'Software Engineer, Telehealth',
      description: 'Build video consultation and scheduling features used by doctors and patients every day.',
      requirements: ['2+ years building web applications', 'Experience with Node.js or Java', 'Care about reliability and privacy'],
      skills: ['Node.js', 'React', 'MongoDB', 'WebRTC'],
      location: 'Bengaluru, India',
      jobType: 'Full-time',
      category: 'Engineering',
      experienceLevel: 'Mid',
      salaryMin: 1400000,
      salaryMax: 2200000,
      currency: 'INR',
      openings: 2,
      deadline: daysFromNow(40),
    },
    {
      company: greenleaf,
      title: 'HR Coordinator',
      description: 'Coordinate onboarding for clinical and admin staff and keep our people records accurate and up to date.',
      requirements: ['Organised and detail oriented', 'Experience with an HR information system is a plus'],
      skills: ['Onboarding', 'Recruiting', 'Communication'],
      location: 'Bengaluru, India',
      jobType: 'Full-time',
      category: 'Human Resources',
      experienceLevel: 'Entry',
      salaryMin: 400000,
      salaryMax: 600000,
      currency: 'INR',
      openings: 1,
      deadline: daysFromNow(22),
    },
  ];

  const jobs = await Job.insertMany(
    jobSeed.map(({ company, ...rest }) => ({ ...rest, company: company._id, postedBy: company.owner }))
  );
  const jobByTitle = (title) => jobs.find((j) => j.title === title);

  // ---- Applications --------------------------------------------------------
  // [applicant index, job title, final status, cover letter]
  const applicationSeed = [
    [0, 'Full-Stack Developer (MERN)', 'Shortlisted', 'I have shipped three MERN apps and enjoy owning features end to end.'],
    [0, 'Junior Frontend Engineer', 'Under Review', 'React is my daily tool and I would love to grow with your team.'],
    [0, 'Software Engineer, Telehealth', 'Interview Scheduled', 'Building reliable healthcare tools matters to me.'],
    [1, 'Product Designer', 'Offered', 'I design and prototype in code, which shortens handoff with developers.'],
    [1, 'Design Intern', 'Rejected', 'Applying to see if a mentoring role could work alongside my current job.'],
    [2, 'Data Analyst, Operations', 'Hired', 'Operational data is where I do my best work.'],
    [2, 'Financial Analyst', 'Under Review', 'My statistics background and SQL skills transfer well to forecasting.'],
    [3, 'Digital Marketing Executive', 'Applied', 'I have grown a newsletter from 500 to 6,000 subscribers.'],
    [3, 'Customer Support Specialist', 'Withdrawn', 'Looking for flexible hours.'],
    [4, 'Junior Frontend Engineer', 'Applied', 'I am a recent graduate eager to work on a real product.'],
    [4, 'Software Engineer, Telehealth', 'Rejected', 'My capstone was a booking platform with scheduling logic.'],
    [1, 'Brand Strategist (Contract)', 'Applied', 'I have facilitated naming workshops for two startups.'],
  ];

  // Status path used to build a believable history for each application.
  const path = {
    Applied: ['Applied'],
    'Under Review': ['Applied', 'Under Review'],
    Shortlisted: ['Applied', 'Under Review', 'Shortlisted'],
    'Interview Scheduled': ['Applied', 'Under Review', 'Shortlisted', 'Interview Scheduled'],
    Offered: ['Applied', 'Under Review', 'Shortlisted', 'Interview Scheduled', 'Offered'],
    Hired: ['Applied', 'Under Review', 'Shortlisted', 'Interview Scheduled', 'Offered', 'Hired'],
    Rejected: ['Applied', 'Under Review', 'Rejected'],
    Withdrawn: ['Applied', 'Withdrawn'],
  };

  for (const [ai, title, status, coverLetter] of applicationSeed) {
    const job = jobByTitle(title);
    const { user, profile } = applicants[ai];
    const steps = path[status];
    const start = Date.now() - (steps.length + 2) * 24 * 60 * 60 * 1000;
    await Application.create({
      job: job._id,
      company: job.company,
      applicant: profile._id,
      coverLetter,
      resumeUrl: profile.resumeUrl,
      status,
      statusHistory: steps.map((s, idx) => ({
        status: s,
        changedBy: s === 'Applied' || s === 'Withdrawn' ? user._id : job.postedBy,
        changedAt: new Date(start + idx * 24 * 60 * 60 * 1000),
      })),
    });
  }

  console.log('\nSeed complete.');
  console.log(`  Users:        ${await User.countDocuments()} (1 admin, ${employers.length} employers, ${applicants.length} applicants)`);
  console.log(`  Companies:    ${await Company.countDocuments()}`);
  console.log(`  Jobs:         ${await Job.countDocuments()}`);
  console.log(`  Applications: ${await Application.countDocuments()}`);
  console.log('\nDemo logins');
  console.log(`  Admin      ${admin.email} / Admin@123`);
  console.log('  Employer   employer1@jobportal.com / Employer@123   (also employer2, employer3)');
  console.log('  Applicant  applicant1@jobportal.com / Applicant@123 (also applicant2 to applicant5)\n');
};

run()
  .catch((err) => {
    console.error('Seeding failed:', err.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect();
  });
