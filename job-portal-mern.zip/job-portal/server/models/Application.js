const mongoose = require('mongoose');
const { APPLICATION_STATUSES } = require('../constants');

const historySchema = new mongoose.Schema(
  {
    status: { type: String, enum: APPLICATION_STATUSES, required: true },
    note: { type: String, trim: true, maxlength: 500, default: '' },
    changedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    changedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const applicationSchema = new mongoose.Schema(
  {
    job: { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true, index: true },
    company: { type: mongoose.Schema.Types.ObjectId, ref: 'Company', required: true, index: true },
    applicant: { type: mongoose.Schema.Types.ObjectId, ref: 'Applicant', required: true, index: true },
    coverLetter: { type: String, trim: true, maxlength: 4000, default: '' },
    resumeUrl: { type: String, trim: true, maxlength: 300, default: '' },
    status: { type: String, enum: APPLICATION_STATUSES, default: 'Applied' },
    statusHistory: { type: [historySchema], default: [] },
  },
  { timestamps: true }
);

// One application per applicant per job.
applicationSchema.index({ job: 1, applicant: 1 }, { unique: true });

module.exports = mongoose.model('Application', applicationSchema);
