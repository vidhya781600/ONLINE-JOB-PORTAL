const mongoose = require('mongoose');
const { COMPANY_SIZES } = require('../constants');

const companySchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    name: {
      type: String,
      required: [true, 'Company name is required'],
      trim: true,
      unique: true,
      maxlength: 120,
    },
    industry: { type: String, trim: true, maxlength: 80, default: '' },
    location: { type: String, trim: true, maxlength: 120, default: '' },
    website: { type: String, trim: true, maxlength: 200, default: '' },
    size: { type: String, enum: [...COMPANY_SIZES, ''], default: '' },
    foundedYear: { type: Number, min: 1800, max: 2100 },
    description: { type: String, trim: true, maxlength: 3000, default: '' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Company', companySchema);
