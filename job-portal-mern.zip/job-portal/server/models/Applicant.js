const mongoose = require('mongoose');

// Applicant profile. One per user with the "applicant" role.
const applicantSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true,
    },
    headline: { type: String, trim: true, maxlength: 140, default: '' },
    phone: { type: String, trim: true, maxlength: 30, default: '' },
    location: { type: String, trim: true, maxlength: 120, default: '' },
    summary: { type: String, trim: true, maxlength: 3000, default: '' },
    skills: { type: [String], default: [] },
    experienceYears: { type: Number, min: [0, 'Experience cannot be negative'], default: 0 },
    education: { type: String, trim: true, maxlength: 300, default: '' },
    resumeUrl: { type: String, trim: true, maxlength: 300, default: '' },
    linkedin: { type: String, trim: true, maxlength: 300, default: '' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Applicant', applicantSchema);
