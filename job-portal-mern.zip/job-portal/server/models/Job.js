const mongoose = require('mongoose');
const { JOB_TYPES, CATEGORIES, EXPERIENCE_LEVELS } = require('../constants');

const jobSchema = new mongoose.Schema(
  {
    company: { type: mongoose.Schema.Types.ObjectId, ref: 'Company', required: true, index: true },
    postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: [true, 'Job title is required'], trim: true, maxlength: 140 },
    description: {
      type: String,
      required: [true, 'Job description is required'],
      trim: true,
      maxlength: 8000,
    },
    requirements: { type: [String], default: [] },
    skills: { type: [String], default: [] },
    location: { type: String, required: [true, 'Location is required'], trim: true, maxlength: 120 },
    jobType: { type: String, enum: JOB_TYPES, default: 'Full-time' },
    category: { type: String, enum: CATEGORIES, default: 'Other' },
    experienceLevel: { type: String, enum: EXPERIENCE_LEVELS, default: 'Entry' },
    salaryMin: { type: Number, min: [0, 'Salary cannot be negative'], default: null },
    salaryMax: { type: Number, min: [0, 'Salary cannot be negative'], default: null },
    currency: {
      type: String,
      uppercase: true,
      trim: true,
      match: [/^[A-Za-z]{3}$/, 'Currency must be a 3-letter code such as USD'],
      default: 'USD',
    },
    openings: { type: Number, min: [1, 'There must be at least one opening'], default: 1 },
    deadline: { type: Date, default: null },
    status: { type: String, enum: ['open', 'closed'], default: 'open' },
  },
  { timestamps: true }
);

jobSchema.pre('validate', function () {
  if (this.salaryMin != null && this.salaryMax != null && this.salaryMax < this.salaryMin) {
    this.invalidate('salaryMax', 'Maximum salary cannot be lower than minimum salary');
  }
});

jobSchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model('Job', jobSchema);
