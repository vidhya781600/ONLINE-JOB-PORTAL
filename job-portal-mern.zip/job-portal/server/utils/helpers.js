const mongoose = require('mongoose');

const escapeRegex = (s = '') => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Accepts an array or a comma/newline separated string and returns a clean array.
const toList = (v) => {
  if (v === undefined || v === null) return [];
  const arr = Array.isArray(v) ? v : String(v).split(/[,\n]/);
  return arr.map((x) => String(x).trim()).filter(Boolean);
};

const numOrNull = (v) => (v === '' || v === null || v === undefined ? null : Number(v));

const pick = (obj = {}, keys = []) =>
  keys.reduce((acc, k) => {
    if (obj[k] !== undefined) acc[k] = obj[k];
    return acc;
  }, {});

const getPaging = (query, defaultLimit = 10, maxLimit = 100) => {
  const page = Math.max(parseInt(query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(query.limit, 10) || defaultLimit, 1), maxLimit);
  return { page, limit, skip: (page - 1) * limit };
};

const isId = (v) => mongoose.Types.ObjectId.isValid(v);

// Admin can manage anything; otherwise the user must be the owner.
const canManage = (user, ownerId) =>
  user.role === 'admin' || String(ownerId) === String(user._id);

module.exports = { escapeRegex, toList, numOrNull, pick, getPaging, isId, canManage };
