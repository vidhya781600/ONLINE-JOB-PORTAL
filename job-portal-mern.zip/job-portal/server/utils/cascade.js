const User = require('../models/User');
const Company = require('../models/Company');
const Job = require('../models/Job');
const Applicant = require('../models/Applicant');
const Application = require('../models/Application');

const deleteJobs = async (jobIds) => {
  if (!jobIds.length) return;
  await Application.deleteMany({ job: { $in: jobIds } });
  await Job.deleteMany({ _id: { $in: jobIds } });
};

const deleteCompanies = async (companyIds) => {
  if (!companyIds.length) return;
  const jobIds = await Job.distinct('_id', { company: { $in: companyIds } });
  await deleteJobs(jobIds);
  await Application.deleteMany({ company: { $in: companyIds } });
  await Company.deleteMany({ _id: { $in: companyIds } });
};

const deleteUser = async (user) => {
  if (user.role === 'applicant') {
    const profile = await Applicant.findOne({ user: user._id });
    if (profile) {
      await Application.deleteMany({ applicant: profile._id });
      await Applicant.deleteOne({ _id: profile._id });
    }
  }
  if (user.role === 'employer') {
    const companyIds = await Company.distinct('_id', { owner: user._id });
    await deleteCompanies(companyIds);
  }
  await User.deleteOne({ _id: user._id });
};

module.exports = { deleteJobs, deleteCompanies, deleteUser };
