// Loads server/.env and fills safe defaults so the app still starts if .env is missing.
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

process.env.PORT = process.env.PORT || '5000';
process.env.MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/job_portal';
process.env.JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
if (!process.env.JWT_SECRET) {
  console.warn('JWT_SECRET is not set. Using a development secret. Set one in server/.env.');
  process.env.JWT_SECRET = 'dev_only_secret_change_me';
}

module.exports = process.env;
