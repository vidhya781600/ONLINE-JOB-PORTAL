export const JOB_TYPES = ['Full-time', 'Part-time', 'Contract', 'Internship', 'Remote'];
export const CATEGORIES = [
  'Engineering',
  'Design',
  'Marketing',
  'Sales',
  'Finance',
  'Human Resources',
  'Operations',
  'Customer Support',
  'Data & Analytics',
  'Other',
];
export const EXPERIENCE_LEVELS = ['Entry', 'Mid', 'Senior'];
export const COMPANY_SIZES = ['1-10', '11-50', '51-200', '201-500', '501+'];
export const STATUSES = [
  'Applied',
  'Under Review',
  'Shortlisted',
  'Interview Scheduled',
  'Offered',
  'Hired',
  'Rejected',
  'Withdrawn',
];
// Statuses an employer can set (Withdrawn belongs to the applicant).
export const EMPLOYER_STATUSES = STATUSES.filter((s) => s !== 'Withdrawn');

export const formatMoney = (n, currency = 'USD') => {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
      notation: 'compact',
      maximumFractionDigits: 1,
    }).format(n);
  } catch (e) {
    return String(n);
  }
};

export const formatSalary = (job) => {
  const { salaryMin: min, salaryMax: max, currency } = job;
  const hasMin = min !== null && min !== undefined;
  const hasMax = max !== null && max !== undefined;
  if (!hasMin && !hasMax) return 'Salary not listed';
  if (hasMin && hasMax) return `${formatMoney(min, currency)} to ${formatMoney(max, currency)} a year`;
  if (hasMin) return `From ${formatMoney(min, currency)} a year`;
  return `Up to ${formatMoney(max, currency)} a year`;
};

export const formatDate = (d) =>
  d ? new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : '';

export const timeAgo = (d) => {
  if (!d) return '';
  const days = Math.floor((Date.now() - new Date(d).getTime()) / 86400000);
  if (days <= 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 30) return `${days} days ago`;
  const months = Math.floor(days / 30);
  return months === 1 ? '1 month ago' : `${months} months ago`;
};

export const statusSlug = (s = '') => s.toLowerCase().replace(/\s+/g, '-');
