import { useEffect, useState } from 'react';
import api, { errMsg } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';

const blank = {
  name: '',
  headline: '',
  phone: '',
  location: '',
  skills: '',
  experienceYears: 0,
  education: '',
  summary: '',
  resumeUrl: '',
  linkedin: '',
};

export default function ApplicantProfile() {
  const { user, setUser } = useAuth();
  const [form, setForm] = useState(blank);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState('');

  useEffect(() => {
    api
      .get('/applicants/me')
      .then((r) => {
        const p = r.data;
        setForm({
          name: p.user?.name || user?.name || '',
          headline: p.headline || '',
          phone: p.phone || '',
          location: p.location || '',
          skills: (p.skills || []).join(', '),
          experienceYears: p.experienceYears ?? 0,
          education: p.education || '',
          summary: p.summary || '',
          resumeUrl: p.resumeUrl || '',
          linkedin: p.linkedin || '',
        });
      })
      .catch((e) => setError(errMsg(e)))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSaved('');
    try {
      const { data } = await api.put('/applicants/me', form);
      if (data.user?.name && data.user.name !== user.name) setUser({ ...user, name: data.user.name });
      setSaved('Profile saved.');
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loader label="Loading profile" />;

  return (
    <section className="narrow">
      <h1>Your profile</h1>
      <p className="lede">Employers see this when you apply. Keep it short and current.</p>
      <form onSubmit={submit} className="form-grid">
        <Alert>{error}</Alert>
        <Alert type="success">{saved}</Alert>

        <div className="field">
          <label htmlFor="name">Full name</label>
          <input id="name" required value={form.name} onChange={set('name')} />
        </div>
        <div className="field">
          <label htmlFor="headline">Headline</label>
          <input id="headline" maxLength={140} value={form.headline} onChange={set('headline')} placeholder="For example: Full-stack developer focused on React" />
        </div>
        <div className="field-row">
          <div className="field">
            <label htmlFor="phone">Phone</label>
            <input id="phone" value={form.phone} onChange={set('phone')} />
          </div>
          <div className="field">
            <label htmlFor="location">Location</label>
            <input id="location" value={form.location} onChange={set('location')} />
          </div>
        </div>
        <div className="field">
          <label htmlFor="skills">Skills</label>
          <input id="skills" value={form.skills} onChange={set('skills')} placeholder="Separate with commas: React, Node.js, MongoDB" />
        </div>
        <div className="field-row">
          <div className="field">
            <label htmlFor="exp">Years of experience</label>
            <input id="exp" type="number" min="0" max="60" value={form.experienceYears} onChange={set('experienceYears')} />
          </div>
          <div className="field">
            <label htmlFor="edu">Education</label>
            <input id="edu" value={form.education} onChange={set('education')} />
          </div>
        </div>
        <div className="field">
          <label htmlFor="summary">Summary</label>
          <textarea id="summary" rows={4} maxLength={3000} value={form.summary} onChange={set('summary')} />
        </div>
        <div className="field-row">
          <div className="field">
            <label htmlFor="resume">Resume link</label>
            <input id="resume" type="url" value={form.resumeUrl} onChange={set('resumeUrl')} placeholder="https://" />
          </div>
          <div className="field">
            <label htmlFor="linkedin">LinkedIn</label>
            <input id="linkedin" type="url" value={form.linkedin} onChange={set('linkedin')} placeholder="https://" />
          </div>
        </div>
        <div>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Saving' : 'Save profile'}
          </button>
        </div>
      </form>
    </section>
  );
}
