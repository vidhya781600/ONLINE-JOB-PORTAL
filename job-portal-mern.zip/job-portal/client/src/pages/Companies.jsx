import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Empty from '../components/Empty.jsx';
import Monogram from '../components/Monogram.jsx';
import Pagination from '../components/Pagination.jsx';

export default function Companies() {
  const [draft, setDraft] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState({ companies: [], total: 0, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError('');
    api
      .get('/companies', { params: { search: search || undefined, page, limit: 10 } })
      .then((r) => active && setData(r.data))
      .catch((e) => active && setError(errMsg(e)))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [search, page]);

  const submit = (e) => {
    e.preventDefault();
    setPage(1);
    setSearch(draft.trim());
  };

  return (
    <section>
      <h1>Companies</h1>
      <form className="inline-search" onSubmit={submit} role="search">
        <label className="sr-only" htmlFor="cs">Search companies</label>
        <input
          id="cs"
          type="text"
          placeholder="Search by name, industry or city"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
        />
        <button type="submit" className="btn btn-primary">Search</button>
      </form>

      <Alert>{error}</Alert>
      {loading ? (
        <Loader label="Loading companies" />
      ) : data.companies.length === 0 ? (
        <Empty title="No companies found">Try a different search.</Empty>
      ) : (
        <div className="job-list">
          {data.companies.map((c) => (
            <Link to={`/companies/${c._id}`} className="job-row" key={c._id}>
              <Monogram name={c.name} />
              <div className="job-main">
                <h3>{c.name}</h3>
                <p className="job-sub">
                  {c.industry && <span>{c.industry}</span>}
                  {c.location && <span>{c.location}</span>}
                  {c.size && <span>{c.size} people</span>}
                </p>
              </div>
              <div className="job-side">
                <span className="tag">{c.openJobs} open {c.openJobs === 1 ? 'role' : 'roles'}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
      <Pagination page={page} pages={data.pages} onChange={setPage} />
    </section>
  );
}
