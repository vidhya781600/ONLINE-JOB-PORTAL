import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Empty from '../components/Empty.jsx';
import Monogram from '../components/Monogram.jsx';
import { COMPANY_SIZES } from '../constants.js';

const blank = { name: '', industry: '', location: '', website: '', size: '', foundedYear: '', description: '' };

export default function EmployerCompanies() {
  const [companies, setCompanies] = useState([]);
  const [form, setForm] = useState(blank);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(async () => {
    try {
      const { data } = await api.get('/companies/mine');
      setCompanies(data);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const startEdit = (c) => {
    setEditingId(c._id);
    setNotice('');
    setError('');
    setForm({
      name: c.name || '',
      industry: c.industry || '',
      location: c.location || '',
      website: c.website || '',
      size: c.size || '',
      foundedYear: c.foundedYear || '',
      description: c.description || '',
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setForm(blank);
  };

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setNotice('');
    try {
      if (editingId) {
        await api.put(`/companies/${editingId}`, form);
        setNotice('Company updated.');
      } else {
        await api.post('/companies', form);
        setNotice('Company created. You can now post jobs for it.');
      }
      cancelEdit();
      await load();
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setSaving(false);
    }
  };

  const remove = async (c) => {
    if (!window.confirm(`Delete ${c.name}? Its jobs and their applications will be deleted too.`)) return;
    try {
      await api.delete(`/companies/${c._id}`);
      if (editingId === c._id) cancelEdit();
      await load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  if (loading) return <Loader label="Loading companies" />;

  return (
    <section className="two-col">
      <div>
        <h1>My companies</h1>
        {companies.length === 0 ? (
          <Empty title="No companies yet">Use the form to add the company you are hiring for.</Empty>
        ) : (
          <div className="job-list">
            {companies.map((c) => (
              <div className="job-row static" key={c._id}>
                <Monogram name={c.name} />
                <div className="job-main">
                  <h3><Link to={`/companies/${c._id}`}>{c.name}</Link></h3>
                  <p className="job-sub">
                    {c.industry && <span>{c.industry}</span>}
                    {c.location && <span>{c.location}</span>}
                    <span>{c.openJobs} open {c.openJobs === 1 ? 'role' : 'roles'}</span>
                  </p>
                </div>
                <div className="job-side row-actions">
                  <button type="button" className="btn btn-ghost" onClick={() => startEdit(c)}>Edit</button>
                  <button type="button" className="btn btn-danger-ghost" onClick={() => remove(c)}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <form onSubmit={submit} className="panel form-grid">
        <h2>{editingId ? 'Edit company' : 'Add a company'}</h2>
        <Alert>{error}</Alert>
        <Alert type="success">{notice}</Alert>
        <div className="field">
          <label htmlFor="c-name">Company name</label>
          <input id="c-name" required value={form.name} onChange={set('name')} />
        </div>
        <div className="field-row">
          <div className="field">
            <label htmlFor="c-ind">Industry</label>
            <input id="c-ind" value={form.industry} onChange={set('industry')} />
          </div>
          <div className="field">
            <label htmlFor="c-loc">Location</label>
            <input id="c-loc" value={form.location} onChange={set('location')} />
          </div>
        </div>
        <div className="field">
          <label htmlFor="c-web">Website</label>
          <input id="c-web" type="url" value={form.website} onChange={set('website')} placeholder="https://" />
        </div>
        <div className="field-row">
          <div className="field">
            <label htmlFor="c-size">Company size</label>
            <select id="c-size" value={form.size} onChange={set('size')}>
              <option value="">Not specified</option>
              {COMPANY_SIZES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="c-year">Founded</label>
            <input id="c-year" type="number" min="1800" max="2100" value={form.foundedYear} onChange={set('foundedYear')} />
          </div>
        </div>
        <div className="field">
          <label htmlFor="c-desc">About the company</label>
          <textarea id="c-desc" rows={4} maxLength={3000} value={form.description} onChange={set('description')} />
        </div>
        <div className="actions">
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Saving' : editingId ? 'Save changes' : 'Create company'}
          </button>
          {editingId && <button type="button" className="btn btn-ghost" onClick={cancelEdit}>Cancel</button>}
        </div>
      </form>
    </section>
  );
}
