import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Empty from '../components/Empty.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import StatStrip from '../components/StatStrip.jsx';
import { formatDate } from '../constants.js';

export default function MyApplications() {
  const [apps, setApps] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setError('');
    try {
      const [a, s] = await Promise.all([api.get('/applications/mine'), api.get('/stats')]);
      setApps(a.data);
      setStats(s.data);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const withdraw = async (id) => {
    if (!window.confirm('Withdraw this application?')) return;
    try {
      await api.put(`/applications/${id}/withdraw`);
      await load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  const remove = async (id) => {
    if (!window.confirm('Delete this application from your list?')) return;
    try {
      await api.delete(`/applications/${id}`);
      await load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  if (loading) return <Loader label="Loading your applications" />;

  return (
    <section>
      <h1>My applications</h1>
      <Alert>{error}</Alert>
      <StatStrip stats={stats} />

      {apps.length === 0 ? (
        <Empty title="You have not applied to any jobs yet">
          <Link to="/">Browse open jobs</Link> and apply to get started.
        </Empty>
      ) : (
        <div className="table-wrap">
          <table className="grid">
            <thead>
              <tr>
                <th>Job</th>
                <th>Company</th>
                <th>Applied</th>
                <th>Status</th>
                <th>History</th>
                <th><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {apps.map((a) => {
                const canWithdraw = !['Hired', 'Rejected', 'Withdrawn'].includes(a.status);
                return (
                  <tr key={a._id}>
                    <td>
                      {a.job ? <Link to={`/jobs/${a.job._id}`}>{a.job.title}</Link> : 'Job removed'}
                      {a.job && <small className="block">{a.job.location}</small>}
                    </td>
                    <td>{a.company?.name}</td>
                    <td>{formatDate(a.createdAt)}</td>
                    <td><StatusBadge status={a.status} /></td>
                    <td>
                      <details>
                        <summary>{a.statusHistory?.length || 0} updates</summary>
                        <ol className="history">
                          {(a.statusHistory || []).map((h, i) => (
                            <li key={i}>
                              <StatusBadge status={h.status} /> <small>{formatDate(h.changedAt)}</small>
                            </li>
                          ))}
                        </ol>
                      </details>
                    </td>
                    <td className="row-actions">
                      {canWithdraw && (
                        <button type="button" className="btn btn-ghost" onClick={() => withdraw(a._id)}>Withdraw</button>
                      )}
                      <button type="button" className="btn btn-danger-ghost" onClick={() => remove(a._id)}>Delete</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
