import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Monogram from '../components/Monogram.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { formatSalary, formatDate, timeAgo } from '../constants.js';

export default function JobDetails() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [myApplication, setMyApplication] = useState(null);
  const [form, setForm] = useState({ coverLetter: '', resumeUrl: '' });
  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState('');
  const [applyError, setApplyError] = useState('');

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError('');
    api
      .get(`/jobs/${id}`)
      .then((r) => active && setJob(r.data))
      .catch((e) => active && setError(errMsg(e)))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [id]);

  useEffect(() => {
    if (user?.role !== 'applicant') {
      setMyApplication(null);
      return;
    }
    api
      .get('/applications/mine')
      .then((r) => setMyApplication(r.data.find((a) => a.job?._id === id) || null))
      .catch(() => {});
  }, [user, id]);

  const apply = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setApplyError('');
    try {
      const { data } = await api.post('/applications', { jobId: id, ...form });
      setMyApplication({ ...data, job: { _id: id } });
      setNotice('Your application was sent. You can follow its status under My applications.');
    } catch (err) {
      setApplyError(errMsg(err));
    } finally {
      setSubmitting(false);
    }
  };

  const remove = async () => {
    if (!window.confirm('Delete this job and all of its applications?')) return;
    try {
      await api.delete(`/jobs/${id}`);
      navigate(user.role === 'admin' ? '/admin' : '/employer');
    } catch (err) {
      setError(errMsg(err));
    }
  };

  if (loading) return <Loader label="Loading job" />;
  if (error && !job) return <Alert>{error}</Alert>;
  if (!job) return null;

  const company = job.company || {};
  const canManage = user && (user.role === 'admin' || (user.role === 'employer' && String(job.postedBy) === String(user._id)));
  const expired = job.deadline && new Date(job.deadline) < new Date();
  const closed = job.status === 'closed' || expired;

  return (
    <article className="detail">
      <Link to="/" className="back-link">Back to all jobs</Link>

      <header className="detail-head">
        <Monogram name={company.name || 'Company'} size={64} />
        <div>
          <h1>{job.title}</h1>
          <p className="job-sub">
            {company._id ? <Link to={`/companies/${company._id}`}>{company.name}</Link> : <span>{company.name}</span>}
            <span>{job.location}</span>
            <span>Posted {timeAgo(job.createdAt)}</span>
          </p>
        </div>
      </header>

      <Alert>{error}</Alert>

      <div className="split split-detail">
        <div className="prose">
          <h2>About the role</h2>
          <p className="pre-wrap">{job.description}</p>

          {job.requirements?.length > 0 && (
            <>
              <h2>What you should bring</h2>
              <ul>{job.requirements.map((r) => <li key={r}>{r}</li>)}</ul>
            </>
          )}

          {job.skills?.length > 0 && (
            <>
              <h2>Skills</h2>
              <p className="tags">{job.skills.map((s) => <span className="tag" key={s}>{s}</span>)}</p>
            </>
          )}
        </div>

        <aside className="panel">
          <dl className="facts">
            <dt>Pay</dt><dd>{formatSalary(job)}</dd>
            <dt>Job type</dt><dd>{job.jobType}</dd>
            <dt>Category</dt><dd>{job.category}</dd>
            <dt>Experience</dt><dd>{job.experienceLevel}</dd>
            <dt>Openings</dt><dd>{job.openings}</dd>
            {job.deadline && (<><dt>Apply by</dt><dd>{formatDate(job.deadline)}</dd></>)}
            <dt>Status</dt><dd>{closed ? 'Closed' : 'Open'}</dd>
          </dl>

          {canManage && (
            <div className="actions">
              <Link className="btn btn-primary" to={`/employer/jobs/${job._id}/applications`}>View applications</Link>
              <Link className="btn btn-ghost" to={`/employer/jobs/${job._id}/edit`}>Edit job</Link>
              <button type="button" className="btn btn-danger" onClick={remove}>Delete job</button>
            </div>
          )}

          {!user && (
            <div className="apply-box">
              <p>Log in as an applicant to apply for this job.</p>
              <Link className="btn btn-primary" to="/login" state={{ from: `/jobs/${job._id}` }}>Log in to apply</Link>
            </div>
          )}

          {user?.role === 'applicant' && (
            <div className="apply-box">
              {myApplication ? (
                <>
                  <p>You applied to this job.</p>
                  <StatusBadge status={myApplication.status} />
                  <Alert type="success">{notice}</Alert>
                </>
              ) : closed ? (
                <p>This job is no longer accepting applications.</p>
              ) : (
                <form onSubmit={apply}>
                  <h3>Apply for this job</h3>
                  <Alert>{applyError}</Alert>
                  <div className="field">
                    <label htmlFor="cl">Cover letter</label>
                    <textarea
                      id="cl"
                      rows={5}
                      maxLength={4000}
                      value={form.coverLetter}
                      onChange={(e) => setForm({ ...form, coverLetter: e.target.value })}
                      placeholder="Tell the employer why you are a good fit."
                    />
                  </div>
                  <div className="field">
                    <label htmlFor="ru">Resume link</label>
                    <input
                      id="ru"
                      type="url"
                      value={form.resumeUrl}
                      onChange={(e) => setForm({ ...form, resumeUrl: e.target.value })}
                      placeholder="Leave blank to use the link on your profile"
                    />
                  </div>
                  <button type="submit" className="btn btn-primary" disabled={submitting}>
                    {submitting ? 'Sending' : 'Send application'}
                  </button>
                </form>
              )}
            </div>
          )}
        </aside>
      </div>
    </article>
  );
}
