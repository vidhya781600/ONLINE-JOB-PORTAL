import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';
import { errMsg } from '../api.js';
import Alert from '../components/Alert.jsx';

const DEMO = [
  { label: 'Applicant', email: 'applicant1@jobportal.com', password: 'Applicant@123' },
  { label: 'Employer', email: 'employer1@jobportal.com', password: 'Employer@123' },
  { label: 'Admin', email: 'admin@jobportal.com', password: 'Admin@123' },
];

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await login(form.email, form.password);
      navigate(location.state?.from || '/dashboard', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth">
      <h1>Log in</h1>
      <form onSubmit={submit}>
        <Alert>{error}</Alert>
        <div className="field">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            required
            autoComplete="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
        </div>
        <div className="field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            required
            autoComplete="current-password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />
        </div>
        <button type="submit" className="btn btn-primary btn-block" disabled={busy}>
          {busy ? 'Logging in' : 'Log in'}
        </button>
      </form>
      <p className="auth-alt">
        New here? <Link to="/register">Create an account</Link>
      </p>

      <div className="demo">
        <p>After running the seed script you can use a demo account:</p>
        <div className="demo-list">
          {DEMO.map((d) => (
            <button
              key={d.label}
              type="button"
              className="btn btn-ghost"
              onClick={() => setForm({ email: d.email, password: d.password })}
            >
              Fill in {d.label.toLowerCase()}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
