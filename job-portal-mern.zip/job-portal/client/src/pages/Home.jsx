import { useCallback, useEffect, useState } from 'react';
import api, { errMsg } from '../api.js';
import JobRow from '../components/JobRow.jsx';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Empty from '../components/Empty.jsx';
import Pagination from '../components/Pagination.jsx';
import { JOB_TYPES, CATEGORIES, EXPERIENCE_LEVELS } from '../constants.js';

const EMPTY = { search: '', location: '', jobType: '', category: '', experienceLevel: '' };

export default function Home() {
  const [draft, setDraft] = useState({ search: '', location: '' });
  const [filters, setFilters] = useState(EMPTY);
  const [page, setPage] = useState(1);
  const [data, setData] = useState({ jobs: [], total: 0, pages: 1 });
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/stats/public').then((r) => setStats(r.data)).catch(() => {});
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = { page, limit: 8 };
      Object.entries(filters).forEach(([k, v]) => {
        if (v) params[k] = v;
      });
      const res = await api.get('/jobs', { params });
      setData(res.data);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [filters, page]);

  useEffect(() => {
    load();
  }, [load]);

  const submitSearch = (e) => {
    e.preventDefault();
    setPage(1);
    setFilters((f) => ({ ...f, search: draft.search.trim(), location: draft.location.trim() }));
  };

  const setSelect = (key) => (e) => {
    setPage(1);
    setFilters((f) => ({ ...f, [key]: e.target.value }));
  };

  const clearAll = () => {
    setDraft({ search: '', location: '' });
    setFilters(EMPTY);
    setPage(1);
  };

  const hasFilters = Object.values(filters).some(Boolean);

  return (
    <>
      <section className="hero">
        <h1>Find work worth showing up for.</h1>
        <p>
          Browse open roles, apply in a minute, and follow every application from Applied through to Hired.
          {stats && (
            <strong className="hero-count">
              {' '}
              {stats.openJobs} open roles at {stats.companies} companies right now.
            </strong>
          )}
        </p>
        <form className="search" onSubmit={submitSearch} role="search">
          <label className="sr-only" htmlFor="q">Job title or skill</label>
          <input
            id="q"
            type="text"
            placeholder="Job title or skill, e.g. React"
            value={draft.search}
            onChange={(e) => setDraft({ ...draft, search: e.target.value })}
          />
          <label className="sr-only" htmlFor="loc">Location</label>
          <input
            id="loc"
            type="text"
            placeholder="City or Remote"
            value={draft.location}
            onChange={(e) => setDraft({ ...draft, location: e.target.value })}
          />
          <button type="submit" className="btn btn-mark">Search jobs</button>
        </form>
      </section>

      <div className="split">
        <aside className="filters" aria-label="Filters">
          <div className="field">
            <label htmlFor="f-type">Job type</label>
            <select id="f-type" value={filters.jobType} onChange={setSelect('jobType')}>
              <option value="">Any type</option>
              {JOB_TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="f-cat">Category</label>
            <select id="f-cat" value={filters.category} onChange={setSelect('category')}>
              <option value="">Any category</option>
              {CATEGORIES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="f-lvl">Experience level</label>
            <select id="f-lvl" value={filters.experienceLevel} onChange={setSelect('experienceLevel')}>
              <option value="">Any level</option>
              {EXPERIENCE_LEVELS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          {hasFilters && (
            <button type="button" className="btn btn-ghost" onClick={clearAll}>Clear filters</button>
          )}
        </aside>

        <section aria-live="polite">
          <p className="result-count">
            {loading ? 'Searching' : `${data.total} ${data.total === 1 ? 'job' : 'jobs'} found`}
          </p>
          <Alert>{error}</Alert>
          {loading ? (
            <Loader label="Loading jobs" />
          ) : data.jobs.length === 0 ? (
            <Empty title="No jobs match these filters">Try a different keyword or clear the filters.</Empty>
          ) : (
            <div className="job-list">
              {data.jobs.map((j) => <JobRow key={j._id} job={j} />)}
            </div>
          )}
          <Pagination page={page} pages={data.pages} onChange={setPage} />
        </section>
      </div>
    </>
  );
}
