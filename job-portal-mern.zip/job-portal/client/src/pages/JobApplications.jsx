import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Empty from '../components/Empty.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { EMPLOYER_STATUSES, formatDate } from '../constants.js';

export default function JobApplications() {
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [apps, setApps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState('');

  const load = useCallback(async () => {
    try {
      const { data } = await api.get(`/applications/job/${id}`);
      setJob(data.job);
      setApps(data.applications);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const changeStatus = async (app, status) => {
    setBusyId(app._id);
    setError('');
    try {
      await api.put(`/applications/${app._id}/status`, { status });
      await load();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusyId('');
    }
  };

  if (loading) return <Loader label="Loading applications" />;
  if (!job) return <Alert>{error}</Alert>;

  return (
    <section>
      <Link to="/employer" className="back-link">Back to dashboard</Link>
      <h1>Applications for {job.title}</h1>
      <p className="lede">{job.company?.name}, {job.location}</p>
      <Alert>{error}</Alert>

      {apps.length === 0 ? (
        <Empty title="No applications yet">They will appear here as people apply.</Empty>
      ) : (
        <div className="table-wrap">
          <table className="grid">
            <thead>
              <tr>
                <th>Applicant</th>
                <th>Experience</th>
                <th>Applied</th>
                <th>Details</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {apps.map((a) => {
                const p = a.applicant || {};
                const locked = a.status === 'Withdrawn';
                return (
                  <tr key={a._id}>
                    <td>
                      <strong>{p.user?.name || 'Unknown'}</strong>
                      <small className="block">{p.user?.email}</small>
                      {p.headline && <small className="block">{p.headline}</small>}
                    </td>
                    <td>
                      {p.experienceYears ?? 0} {p.experienceYears === 1 ? 'year' : 'years'}
                      {p.skills?.length > 0 && (
                        <p className="tags tags-small">
                          {p.skills.slice(0, 4).map((s) => <span key={s} className="tag">{s}</span>)}
                        </p>
                      )}
                    </td>
                    <td>{formatDate(a.createdAt)}</td>
                    <td>
                      <details>
                        <summary>View</summary>
                        <p className="pre-wrap small">{a.coverLetter || 'No cover letter.'}</p>
                        {a.resumeUrl && (
                          <p className="small"><a href={a.resumeUrl} target="_blank" rel="noreferrer">Open resume</a></p>
                        )}
                        {p.phone && <p className="small">Phone: {p.phone}</p>}
                      </details>
                    </td>
                    <td>
                      {locked ? (
                        <StatusBadge status={a.status} />
                      ) : (
                        <>
                          <label className="sr-only" htmlFor={`st-${a._id}`}>Status for {p.user?.name}</label>
                          <select
                            id={`st-${a._id}`}
                            value={a.status}
                            disabled={busyId === a._id}
                            onChange={(e) => changeStatus(a, e.target.value)}
                          >
                            {EMPLOYER_STATUSES.map((s) => <option key={s}>{s}</option>)}
                          </select>
                        </>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
