import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Empty from '../components/Empty.jsx';
import StatStrip from '../components/StatStrip.jsx';
import { formatDate } from '../constants.js';

export default function EmployerDashboard() {
  const [jobs, setJobs] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setError('');
    try {
      const [j, c, s] = await Promise.all([api.get('/jobs/mine'), api.get('/companies/mine'), api.get('/stats')]);
      setJobs(j.data);
      setCompanies(c.data);
      setStats(s.data);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const toggleStatus = async (job) => {
    try {
      await api.put(`/jobs/${job._id}`, { status: job.status === 'open' ? 'closed' : 'open' });
      await load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  const remove = async (job) => {
    if (!window.confirm(`Delete "${job.title}" and all of its applications?`)) return;
    try {
      await api.delete(`/jobs/${job._id}`);
      await load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  if (loading) return <Loader label="Loading dashboard" />;

  return (
    <section>
      <div className="page-head">
        <h1>Employer dashboard</h1>
        {companies.length > 0 && <Link className="btn btn-primary" to="/employer/jobs/new">Post a job</Link>}
      </div>
      <Alert>{error}</Alert>
      <StatStrip stats={stats} />

      {companies.length === 0 ? (
        <Empty title="Add a company before posting jobs">
          <Link to="/employer/companies">Create your first company</Link>.
        </Empty>
      ) : jobs.length === 0 ? (
        <Empty title="No jobs posted yet">
          <Link to="/employer/jobs/new">Post your first job</Link> to start receiving applications.
        </Empty>
      ) : (
        <div className="table-wrap">
          <table className="grid">
            <thead>
              <tr>
                <th>Job</th>
                <th>Company</th>
                <th>Posted</th>
                <th>Status</th>
                <th>Applicants</th>
                <th><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((j) => (
                <tr key={j._id}>
                  <td><Link to={`/jobs/${j._id}`}>{j.title}</Link></td>
                  <td>{j.company?.name}</td>
                  <td>{formatDate(j.createdAt)}</td>
                  <td><span className={`tag ${j.status === 'closed' ? 'tag-muted' : ''}`}>{j.status}</span></td>
                  <td>
                    <Link to={`/employer/jobs/${j._id}/applications`}>{j.applicationCount}</Link>
                  </td>
                  <td className="row-actions">
                    <Link className="btn btn-ghost" to={`/employer/jobs/${j._id}/edit`}>Edit</Link>
                    <button type="button" className="btn btn-ghost" onClick={() => toggleStatus(j)}>
                      {j.status === 'open' ? 'Close' : 'Reopen'}
                    </button>
                    <button type="button" className="btn btn-danger-ghost" onClick={() => remove(j)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
