import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Empty from '../components/Empty.jsx';
import { JOB_TYPES, CATEGORIES, EXPERIENCE_LEVELS } from '../constants.js';

const blank = {
  company: '',
  title: '',
  description: '',
  requirements: '',
  skills: '',
  location: '',
  jobType: 'Full-time',
  category: 'Engineering',
  experienceLevel: 'Entry',
  salaryMin: '',
  salaryMax: '',
  currency: 'USD',
  openings: 1,
  deadline: '',
  status: 'open',
};

export default function JobForm() {
  const { id } = useParams();
  const editing = Boolean(id);
  const navigate = useNavigate();

  const [companies, setCompanies] = useState([]);
  const [form, setForm] = useState(blank);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    const requests = [api.get('/companies/mine')];
    if (editing) requests.push(api.get(`/jobs/${id}`));
    Promise.all(requests)
      .then(([c, j]) => {
        if (!active) return;
        setCompanies(c.data);
        if (j) {
          const job = j.data;
          setForm({
            company: job.company?._id || '',
            title: job.title || '',
            description: job.description || '',
            requirements: (job.requirements || []).join('\n'),
            skills: (job.skills || []).join(', '),
            location: job.location || '',
            jobType: job.jobType,
            category: job.category,
            experienceLevel: job.experienceLevel,
            salaryMin: job.salaryMin ?? '',
            salaryMax: job.salaryMax ?? '',
            currency: job.currency || 'USD',
            openings: job.openings || 1,
            deadline: job.deadline ? job.deadline.slice(0, 10) : '',
            status: job.status,
          });
        } else if (c.data.length > 0) {
          setForm((f) => ({ ...f, company: c.data[0]._id }));
        }
      })
      .catch((e) => active && setError(errMsg(e)))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [id, editing]);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      const payload = { ...form };
      if (editing) delete payload.company; // a job stays with its company
      if (editing) {
        await api.put(`/jobs/${id}`, payload);
        navigate(`/jobs/${id}`);
      } else {
        const { data } = await api.post('/jobs', payload);
        navigate(`/jobs/${data._id}`);
      }
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loader label="Loading form" />;

  if (companies.length === 0) {
    return (
      <Empty title="Add a company first">
        Jobs belong to a company. <Link to="/employer/companies">Create one</Link> and come back.
      </Empty>
    );
  }

  return (
    <section className="narrow">
      <h1>{editing ? 'Edit job' : 'Post a job'}</h1>
      <form onSubmit={submit} className="form-grid">
        <Alert>{error}</Alert>

        <div className="field-row">
          <div className="field">
            <label htmlFor="j-company">Company</label>
            <select id="j-company" required value={form.company} onChange={set('company')} disabled={editing}>
              {companies.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="j-title">Job title</label>
            <input id="j-title" required maxLength={140} value={form.title} onChange={set('title')} />
          </div>
        </div>

        <div className="field">
          <label htmlFor="j-desc">Description</label>
          <textarea id="j-desc" required rows={6} maxLength={8000} value={form.description} onChange={set('description')} />
        </div>
        <div className="field">
          <label htmlFor="j-req">Requirements</label>
          <textarea id="j-req" rows={4} value={form.requirements} onChange={set('requirements')} placeholder="One requirement per line" />
        </div>
        <div className="field">
          <label htmlFor="j-skills">Skills</label>
          <input id="j-skills" value={form.skills} onChange={set('skills')} placeholder="Separate with commas: React, Node.js" />
        </div>

        <div className="field-row">
          <div className="field">
            <label htmlFor="j-loc">Location</label>
            <input id="j-loc" required value={form.location} onChange={set('location')} placeholder="City, or Remote" />
          </div>
          <div className="field">
            <label htmlFor="j-type">Job type</label>
            <select id="j-type" value={form.jobType} onChange={set('jobType')}>
              {JOB_TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
        </div>

        <div className="field-row">
          <div className="field">
            <label htmlFor="j-cat">Category</label>
            <select id="j-cat" value={form.category} onChange={set('category')}>
              {CATEGORIES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="j-lvl">Experience level</label>
            <select id="j-lvl" value={form.experienceLevel} onChange={set('experienceLevel')}>
              {EXPERIENCE_LEVELS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
        </div>

        <div className="field-row field-row-4">
          <div className="field">
            <label htmlFor="j-min">Yearly pay, from</label>
            <input id="j-min" type="number" min="0" value={form.salaryMin} onChange={set('salaryMin')} />
          </div>
          <div className="field">
            <label htmlFor="j-max">Yearly pay, up to</label>
            <input id="j-max" type="number" min="0" value={form.salaryMax} onChange={set('salaryMax')} />
          </div>
          <div className="field">
            <label htmlFor="j-cur">Currency</label>
            <input id="j-cur" maxLength={3} value={form.currency} onChange={set('currency')} placeholder="USD" />
          </div>
          <div className="field">
            <label htmlFor="j-open">Openings</label>
            <input id="j-open" type="number" min="1" value={form.openings} onChange={set('openings')} />
          </div>
        </div>

        <div className="field-row">
          <div className="field">
            <label htmlFor="j-dead">Apply by</label>
            <input id="j-dead" type="date" value={form.deadline} onChange={set('deadline')} />
          </div>
          <div className="field">
            <label htmlFor="j-status">Status</label>
            <select id="j-status" value={form.status} onChange={set('status')}>
              <option value="open">Open</option>
              <option value="closed">Closed</option>
            </select>
          </div>
        </div>

        <div className="actions">
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Saving' : editing ? 'Save changes' : 'Publish job'}
          </button>
          <Link className="btn btn-ghost" to="/employer">Cancel</Link>
        </div>
      </form>
    </section>
  );
}
