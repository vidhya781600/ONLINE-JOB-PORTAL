import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Empty from '../components/Empty.jsx';
import Monogram from '../components/Monogram.jsx';
import JobRow from '../components/JobRow.jsx';

export default function CompanyDetails() {
  const { id } = useParams();
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    setLoading(true);
    api
      .get(`/companies/${id}`)
      .then((r) => active && setCompany(r.data))
      .catch((e) => active && setError(errMsg(e)))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [id]);

  if (loading) return <Loader label="Loading company" />;
  if (error) return <Alert>{error}</Alert>;
  if (!company) return null;

  return (
    <article className="detail">
      <Link to="/companies" className="back-link">Back to companies</Link>
      <header className="detail-head">
        <Monogram name={company.name} size={64} />
        <div>
          <h1>{company.name}</h1>
          <p className="job-sub">
            {company.industry && <span>{company.industry}</span>}
            {company.location && <span>{company.location}</span>}
            {company.size && <span>{company.size} people</span>}
            {company.foundedYear && <span>Founded {company.foundedYear}</span>}
          </p>
          {company.website && (
            <p><a href={company.website} target="_blank" rel="noreferrer">{company.website}</a></p>
          )}
        </div>
      </header>

      {company.description && <p className="pre-wrap prose">{company.description}</p>}

      <h2>Open roles</h2>
      {company.jobs.length === 0 ? (
        <Empty title="No open roles right now">Check back soon.</Empty>
      ) : (
        <div className="job-list">
          {company.jobs.map((j) => <JobRow key={j._id} job={j} />)}
        </div>
      )}
    </article>
  );
}
