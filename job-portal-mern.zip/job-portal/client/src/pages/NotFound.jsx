import { Link } from 'react-router-dom';
import Empty from '../components/Empty.jsx';

export default function NotFound() {
  return (
    <Empty title="Page not found">
      The page you are looking for does not exist. <Link to="/">Go to the job list</Link>.
    </Empty>
  );
}
