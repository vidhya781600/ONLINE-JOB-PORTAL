import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';
import { errMsg } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'applicant' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const user = await register(form);
      navigate(user.role === 'employer' ? '/employer/companies' : '/profile', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth">
      <h1>Create your account</h1>
      <form onSubmit={submit}>
        <Alert>{error}</Alert>

        <fieldset className="role-pick">
          <legend>I want to</legend>
          <label className={form.role === 'applicant' ? 'chosen' : ''}>
            <input
              type="radio"
              name="role"
              value="applicant"
              checked={form.role === 'applicant'}
              onChange={set('role')}
            />
            Find a job
          </label>
          <label className={form.role === 'employer' ? 'chosen' : ''}>
            <input
              type="radio"
              name="role"
              value="employer"
              checked={form.role === 'employer'}
              onChange={set('role')}
            />
            Hire people
          </label>
        </fieldset>

        <div className="field">
          <label htmlFor="name">Full name</label>
          <input id="name" required autoComplete="name" value={form.name} onChange={set('name')} />
        </div>
        <div className="field">
          <label htmlFor="email">Email</label>
          <input id="email" type="email" required autoComplete="email" value={form.email} onChange={set('email')} />
        </div>
        <div className="field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            required
            minLength={6}
            autoComplete="new-password"
            value={form.password}
            onChange={set('password')}
          />
          <small>At least 6 characters.</small>
        </div>
        <button type="submit" className="btn btn-primary btn-block" disabled={busy}>
          {busy ? 'Creating account' : 'Create account'}
        </button>
      </form>
      <p className="auth-alt">
        Already registered? <Link to="/login">Log in</Link>
      </p>
    </div>
  );
}
