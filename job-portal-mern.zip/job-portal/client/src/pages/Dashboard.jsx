import { Navigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';
import Loader from '../components/Loader.jsx';

// Sends each role to its own home page.
export default function Dashboard() {
  const { user, loading } = useAuth();
  if (loading) return <Loader />;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'admin') return <Navigate to="/admin" replace />;
  if (user.role === 'employer') return <Navigate to="/employer" replace />;
  return <Navigate to="/my-applications" replace />;
}
