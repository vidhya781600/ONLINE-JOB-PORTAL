import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import Loader from '../components/Loader.jsx';
import Alert from '../components/Alert.jsx';
import Empty from '../components/Empty.jsx';
import StatStrip from '../components/StatStrip.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { formatDate } from '../constants.js';

const TABS = ['Users', 'Companies', 'Jobs', 'Applications'];

export default function AdminDashboard() {
  const { user: me } = useAuth();
  const [tab, setTab] = useState('Users');
  const [stats, setStats] = useState(null);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const requests = {
        Users: () => api.get('/users', { params: { limit: 100 } }).then((r) => r.data.users),
        Companies: () => api.get('/companies/mine').then((r) => r.data),
        Jobs: () => api.get('/jobs/mine').then((r) => r.data),
        Applications: () => api.get('/applications').then((r) => r.data),
      };
      const [s, list] = await Promise.all([api.get('/stats'), requests[tab]()]);
      setStats(s.data);
      setRows(list);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [tab]);

  useEffect(() => {
    load();
  }, [load]);

  const act = async (fn) => {
    setError('');
    try {
      await fn();
      await load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  const confirmDelete = (message, url) => {
    if (window.confirm(message)) act(() => api.delete(url));
  };

  const toggleActive = (u) => act(() => api.put(`/users/${u._id}/active`, { isActive: !u.isActive }));

  const renderTable = () => {
    if (rows.length === 0) return <Empty title={`No ${tab.toLowerCase()} yet`} />;

    if (tab === 'Users') {
      return (
        <table className="grid">
          <thead>
            <tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th>Account</th><th><span className="sr-only">Actions</span></th></tr>
          </thead>
          <tbody>
            {rows.map((u) => (
              <tr key={u._id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td><span className="tag">{u.role}</span></td>
                <td>{formatDate(u.createdAt)}</td>
                <td>{u.isActive ? 'Active' : 'Deactivated'}</td>
                <td className="row-actions">
                  {u.role !== 'admin' && u._id !== me._id && (
                    <>
                      <button type="button" className="btn btn-ghost" onClick={() => toggleActive(u)}>
                        {u.isActive ? 'Deactivate' : 'Activate'}
                      </button>
                      <button
                        type="button"
                        className="btn btn-danger-ghost"
                        onClick={() => confirmDelete(`Delete ${u.name} and all of their data?`, `/users/${u._id}`)}
                      >
                        Delete
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }

    if (tab === 'Companies') {
      return (
        <table className="grid">
          <thead>
            <tr><th>Company</th><th>Industry</th><th>Location</th><th>Open roles</th><th><span className="sr-only">Actions</span></th></tr>
          </thead>
          <tbody>
            {rows.map((c) => (
              <tr key={c._id}>
                <td><Link to={`/companies/${c._id}`}>{c.name}</Link></td>
                <td>{c.industry}</td>
                <td>{c.location}</td>
                <td>{c.openJobs}</td>
                <td className="row-actions">
                  <button
                    type="button"
                    className="btn btn-danger-ghost"
                    onClick={() => confirmDelete(`Delete ${c.name}, its jobs and their applications?`, `/companies/${c._id}`)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }

    if (tab === 'Jobs') {
      return (
        <table className="grid">
          <thead>
            <tr><th>Job</th><th>Company</th><th>Status</th><th>Applicants</th><th><span className="sr-only">Actions</span></th></tr>
          </thead>
          <tbody>
            {rows.map((j) => (
              <tr key={j._id}>
                <td><Link to={`/jobs/${j._id}`}>{j.title}</Link></td>
                <td>{j.company?.name}</td>
                <td><span className={`tag ${j.status === 'closed' ? 'tag-muted' : ''}`}>{j.status}</span></td>
                <td>{j.applicationCount}</td>
                <td className="row-actions">
                  <button
                    type="button"
                    className="btn btn-danger-ghost"
                    onClick={() => confirmDelete(`Delete "${j.title}" and its applications?`, `/jobs/${j._id}`)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }

    return (
      <table className="grid">
        <thead>
          <tr><th>Applicant</th><th>Job</th><th>Company</th><th>Applied</th><th>Status</th><th><span className="sr-only">Actions</span></th></tr>
        </thead>
        <tbody>
          {rows.map((a) => (
            <tr key={a._id}>
              <td>{a.applicant?.user?.name || 'Unknown'}</td>
              <td>{a.job?.title}</td>
              <td>{a.company?.name}</td>
              <td>{formatDate(a.createdAt)}</td>
              <td><StatusBadge status={a.status} /></td>
              <td className="row-actions">
                <button
                  type="button"
                  className="btn btn-danger-ghost"
                  onClick={() => confirmDelete('Delete this application?', `/applications/${a._id}`)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <section>
      <h1>Admin</h1>
      <Alert>{error}</Alert>
      <StatStrip stats={stats} />

      <div className="tabs" role="tablist" aria-label="Manage records">
        {TABS.map((t) => (
          <button
            key={t}
            type="button"
            role="tab"
            aria-selected={tab === t}
            className={tab === t ? 'tab active' : 'tab'}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </div>

      {loading ? <Loader label={`Loading ${tab.toLowerCase()}`} /> : <div className="table-wrap">{renderTable()}</div>}
    </section>
  );
}
