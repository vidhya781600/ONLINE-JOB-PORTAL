const COLORS = ['#0b5d7a', '#7a3b0b', '#3b5d0b', '#5a2a7a', '#7a0b3b', '#2a4a7a', '#0b7a5d'];

const initials = (name = '') =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join('') || '?';

// A square initials block for a company; colour is derived from the name.
export default function Monogram({ name, size = 44 }) {
  let hash = 0;
  for (let i = 0; i < name.length; i += 1) hash = (hash * 31 + name.charCodeAt(i)) % 997;
  return (
    <span
      className="monogram"
      style={{ background: COLORS[hash % COLORS.length], width: size, height: size, fontSize: size * 0.38 }}
      aria-hidden="true"
    >
      {initials(name)}
    </span>
  );
}
