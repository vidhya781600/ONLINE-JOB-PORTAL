import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const onLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="nav">
      <div className="nav-inner">
        <Link to="/" className="brand">
          <span className="brand-mark" aria-hidden="true" />
          Shortlist
        </Link>

        <nav className="nav-links" aria-label="Main">
          <NavLink to="/" end>Jobs</NavLink>
          <NavLink to="/companies">Companies</NavLink>
          {user?.role === 'applicant' && (
            <>
              <NavLink to="/my-applications">My applications</NavLink>
              <NavLink to="/profile">Profile</NavLink>
            </>
          )}
          {user?.role === 'employer' && (
            <>
              <NavLink to="/employer" end>Dashboard</NavLink>
              <NavLink to="/employer/companies">My companies</NavLink>
            </>
          )}
          {user?.role === 'admin' && <NavLink to="/admin">Admin</NavLink>}
        </nav>

        <div className="nav-user">
          {user ? (
            <>
              <span className="who">
                {user.name}
                <small>{user.role}</small>
              </span>
              <button type="button" className="btn btn-ghost" onClick={onLogout}>Log out</button>
            </>
          ) : (
            <>
              <Link className="btn btn-ghost" to="/login">Log in</Link>
              <Link className="btn btn-primary" to="/register">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
