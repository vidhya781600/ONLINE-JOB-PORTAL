import { statusSlug } from '../constants.js';

export default function StatusBadge({ status }) {
  return <span className={`badge badge-${statusSlug(status)}`}>{status}</span>;
}
