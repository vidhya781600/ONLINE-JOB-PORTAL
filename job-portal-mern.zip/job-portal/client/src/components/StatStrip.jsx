import StatusBadge from './StatusBadge.jsx';

const LABELS = {
  users: 'Users',
  employers: 'Employers',
  applicants: 'Applicants',
  companies: 'Companies',
  jobs: 'Jobs',
  openJobs: 'Open jobs',
  applications: 'Applications',
};

// Totals as a row of figures, then applications broken down by status.
export default function StatStrip({ stats }) {
  if (!stats) return null;
  const entries = Object.entries(stats.totals || {});
  const statuses = Object.entries(stats.byStatus || {}).filter(([, n]) => n > 0);
  return (
    <div className="stats">
      <dl className="stat-row">
        {entries.map(([key, value]) => (
          <div key={key} className="stat">
            <dt>{LABELS[key] || key}</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>
      {statuses.length > 0 && (
        <div className="status-row">
          {statuses.map(([status, n]) => (
            <span key={status} className="status-count">
              <StatusBadge status={status} /> {n}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
