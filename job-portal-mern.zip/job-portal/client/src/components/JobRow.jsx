import { Link } from 'react-router-dom';
import Monogram from './Monogram.jsx';
import { formatSalary, timeAgo } from '../constants.js';

export default function JobRow({ job }) {
  const companyName = job.company?.name || 'Company';
  return (
    <Link to={`/jobs/${job._id}`} className="job-row">
      <Monogram name={companyName} />
      <div className="job-main">
        <h3>{job.title}</h3>
        <p className="job-sub">
          <span>{companyName}</span>
          <span>{job.location}</span>
          <span>{job.category}</span>
        </p>
      </div>
      <div className="job-side">
        <span className="tag">{job.jobType}</span>
        <span className="job-salary">{formatSalary(job)}</span>
        <span className="job-time">{timeAgo(job.createdAt)}</span>
      </div>
    </Link>
  );
}
