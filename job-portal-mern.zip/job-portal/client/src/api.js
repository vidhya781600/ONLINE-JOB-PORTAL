import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('jp_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Turns any axios error into a readable message.
export const errMsg = (e) => {
  if (e?.response?.data?.message) return e.response.data.message;
  if (e?.code === 'ERR_NETWORK') return 'Cannot reach the server. Make sure the API is running on port 5000.';
  return e?.message || 'Something went wrong. Please try again.';
};

export default api;
