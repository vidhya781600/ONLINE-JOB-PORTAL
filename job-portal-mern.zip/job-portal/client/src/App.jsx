import { Navigate, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Home from './pages/Home.jsx';
import JobDetails from './pages/JobDetails.jsx';
import Companies from './pages/Companies.jsx';
import CompanyDetails from './pages/CompanyDetails.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import ApplicantProfile from './pages/ApplicantProfile.jsx';
import MyApplications from './pages/MyApplications.jsx';
import EmployerDashboard from './pages/EmployerDashboard.jsx';
import EmployerCompanies from './pages/EmployerCompanies.jsx';
import JobForm from './pages/JobForm.jsx';
import JobApplications from './pages/JobApplications.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import NotFound from './pages/NotFound.jsx';

export default function App() {
  return (
    <>
      <a href="#main" className="skip-link">Skip to content</a>
      <Navbar />
      <main id="main" className="page">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/jobs/:id" element={<JobDetails />} />
          <Route path="/companies" element={<Companies />} />
          <Route path="/companies/:id" element={<CompanyDetails />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<Dashboard />} />

          <Route path="/profile" element={<ProtectedRoute roles={['applicant']}><ApplicantProfile /></ProtectedRoute>} />
          <Route path="/my-applications" element={<ProtectedRoute roles={['applicant']}><MyApplications /></ProtectedRoute>} />

          <Route path="/employer" element={<ProtectedRoute roles={['employer', 'admin']}><EmployerDashboard /></ProtectedRoute>} />
          <Route path="/employer/companies" element={<ProtectedRoute roles={['employer', 'admin']}><EmployerCompanies /></ProtectedRoute>} />
          <Route path="/employer/jobs/new" element={<ProtectedRoute roles={['employer', 'admin']}><JobForm /></ProtectedRoute>} />
          <Route path="/employer/jobs/:id/edit" element={<ProtectedRoute roles={['employer', 'admin']}><JobForm /></ProtectedRoute>} />
          <Route path="/employer/jobs/:id/applications" element={<ProtectedRoute roles={['employer', 'admin']}><JobApplications /></ProtectedRoute>} />

          <Route path="/admin" element={<ProtectedRoute roles={['admin']}><AdminDashboard /></ProtectedRoute>} />

          <Route path="/home" element={<Navigate to="/" replace />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="footer">Shortlist, a MERN stack job portal project.</footer>
    </>
  );
}
