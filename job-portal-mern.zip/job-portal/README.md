# Shortlist: MERN Online Job Portal

Project 14: Online Job Portal. Employers post jobs and manage applications; applicants search jobs, apply and track their status; an admin oversees everything.

**Stack:** MongoDB (Mongoose), Express.js, React (Vite), Node.js, JWT authentication.

## Features

| Area | What it does |
| --- | --- |
| Authentication | Register, log in, JWT sessions, passwords hashed with bcrypt |
| Role-based access | `admin`, `employer`, `applicant`, enforced on the API and in the React routes |
| Companies | Employers create, edit and delete companies (public company pages show open roles) |
| Jobs | Post, edit, close/reopen and delete jobs. Public search with keyword, location, type, category and experience filters, plus pagination |
| Applicants | Applicant profile (skills, experience, resume link) |
| Applications | Apply with a cover letter, one application per job, withdraw, delete. Employers move applications through statuses |
| Status tracking | Applied, Under Review, Shortlisted, Interview Scheduled, Offered, Hired, Rejected, Withdrawn, with a history per application |
| Dashboards | Role-aware counts and status breakdowns for applicant, employer and admin |
| Admin | Manage users (activate, deactivate, delete), companies, jobs and applications |

## Requirements

- Node.js 18 or newer
- MongoDB running locally on the default port, **or** a MongoDB Atlas connection string

## Setup

```bash
# 1. Install everything (root, server, client)
npm run install-all

# 2. Check server/.env (defaults work for a local MongoDB)
#    MONGO_URI=mongodb://127.0.0.1:27017/job_portal

# 3. Load the demo data (this clears the database first)
npm run seed

# 4. Start the API (port 5000) and the React app (port 5173) together
npm run dev
```

Open http://localhost:5173.

Prefer separate terminals? Run `npm run dev` inside `server/` and inside `client/`.

### Using MongoDB Atlas

Put your connection string in `server/.env`:

```
MONGO_URI=mongodb+srv://<user>:<password>@<cluster>/job_portal?retryWrites=true&w=majority
```

## The seed script (`server/seed.js`)

```bash
cd server
npm run seed            # clear everything and insert demo data
npm run seed:destroy    # clear everything only
```

It creates 1 admin, 3 employers, 5 applicants (with profiles), 4 companies, 12 jobs and 12 applications covering every status.

| Role | Email | Password |
| --- | --- | --- |
| Admin | admin@jobportal.com | Admin@123 |
| Employer | employer1@jobportal.com (also employer2, employer3) | Employer@123 |
| Applicant | applicant1@jobportal.com (also applicant2 to applicant5) | Applicant@123 |

## Project structure

```
job-portal/
  package.json          root scripts (install-all, seed, dev)
  server/
    server.js           Express app entry point
    seed.js             MongoDB setup and demo data
    .env                PORT, MONGO_URI, JWT_SECRET, CLIENT_URL
    config/             env loading, database connection
    models/             User, Company, Job, Applicant, Application
    controllers/        request handling and business rules
    routes/             REST route definitions
    middleware/         auth (protect, authorize) and error handling
    utils/              helpers, cascade deletes
  client/
    vite.config.js      dev server and /api proxy
    src/
      App.jsx           routes
      AuthContext.jsx   login state
      api.js            axios instance
      components/       Navbar, JobRow, StatusBadge, ...
      pages/            Home, JobDetails, dashboards, forms, admin
      styles.css
```

## Data model

- **User**: name, email, password (hashed), role, isActive
- **Company**: owner (User), name, industry, location, website, size, foundedYear, description
- **Job**: company, postedBy, title, description, requirements, skills, location, jobType, category, experienceLevel, salaryMin/Max, currency, openings, deadline, status (open or closed)
- **Applicant**: user, headline, phone, location, summary, skills, experienceYears, education, resumeUrl, linkedin
- **Application**: job, company, applicant, coverLetter, resumeUrl, status, statusHistory. Unique per (job, applicant)

Deleting a company removes its jobs and their applications; deleting a job removes its applications; deleting a user removes their related data.

## REST API

All routes are prefixed with `/api`. Protected routes need the header `Authorization: Bearer <token>`.

| Method | Route | Access | Purpose |
| --- | --- | --- | --- |
| POST | `/auth/register` | public | Create an applicant or employer account |
| POST | `/auth/login` | public | Log in, returns token and user |
| GET | `/auth/me` | any user | Current user |
| GET | `/jobs` | public | Search open jobs (`search`, `location`, `jobType`, `category`, `experienceLevel`, `company`, `page`, `limit`) |
| GET | `/jobs/:id` | public | Job with company |
| GET | `/jobs/mine` | employer, admin | Own jobs (all jobs for admin) with applicant counts |
| POST | `/jobs` | employer, admin | Create a job |
| PUT | `/jobs/:id` | owner, admin | Update a job |
| DELETE | `/jobs/:id` | owner, admin | Delete a job and its applications |
| GET | `/companies` | public | List companies with open role counts |
| GET | `/companies/:id` | public | Company with its open jobs |
| GET | `/companies/mine` | employer, admin | Own companies |
| POST | `/companies` | employer, admin | Create a company |
| PUT | `/companies/:id` | owner, admin | Update a company |
| DELETE | `/companies/:id` | owner, admin | Delete a company and its jobs |
| GET | `/applicants/me` | applicant | Own profile |
| PUT | `/applicants/me` | applicant | Update own profile |
| GET | `/applicants` | admin | List applicant profiles |
| GET | `/applicants/:id` | admin, employer who received an application | One profile |
| POST | `/applications` | applicant | Apply to a job |
| GET | `/applications/mine` | applicant | Own applications |
| GET | `/applications` | employer, admin | Applications for own companies (all for admin) |
| GET | `/applications/job/:jobId` | job owner, admin | Applications for one job |
| PUT | `/applications/:id/status` | job owner, admin | Change status |
| PUT | `/applications/:id/withdraw` | applicant | Withdraw own application |
| DELETE | `/applications/:id` | applicant (own), admin | Delete an application |
| GET | `/stats/public` | public | Open job and company counts |
| GET | `/stats` | any user | Role-aware dashboard counts |
| GET | `/users` | admin | List users |
| PUT | `/users/:id/active` | admin | Activate or deactivate a user |
| DELETE | `/users/:id` | admin | Delete a user and related data |
| GET | `/health` | public | Health check |

## Troubleshooting

- **"Could not connect to MongoDB"**: start MongoDB (`mongod`) or point `MONGO_URI` at Atlas.
- **Port already in use**: change `PORT` in `server/.env` and the proxy target in `client/vite.config.js`.
- **Login fails after changing data by hand**: run `npm run seed` again to reset to the demo data.
- **Production build**: `npm run build` creates `client/dist`. Serve it with any static host and set `CLIENT_URL` on the API to that origin.
